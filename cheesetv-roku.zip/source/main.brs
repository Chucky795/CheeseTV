' CheeseTV for Roku - entry point. MIT License, (c) 2026 CheeseTV (watchcheesetv.com).
' Ships EMPTY: no streams, playlists, servers or credentials are included.
sub Main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    while true
        msg = wait(0, port)
        if type(msg) = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        end if
    end while
end sub
