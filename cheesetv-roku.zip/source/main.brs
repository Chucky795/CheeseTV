' CheeseTV for Roku - entry point. MIT License, (c) 2026 CheeseTV (watchcheesetv.com).
' Ships EMPTY: no streams, playlists, servers or credentials are included.
sub Main(args as dynamic)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("MainScene")
    screen.show()
    ' Deep-link parameters (contentId / mediaType) are accepted but there is no catalog to link into:
    ' all content comes from the user's own playlist, so the app just opens normally.
    if type(args) = "roAssociativeArray" then scene.launchArgs = args
    scene.observeField("exitApp", port)
    input = CreateObject("roInput")
    input.setMessagePort(port)
    while true
        msg = wait(0, port)
        t = type(msg)
        if t = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if t = "roSGNodeEvent"
            if msg.getField() = "exitApp" and msg.getData() = true
                screen.close()
                return
            end if
        else if t = "roInputEvent"
            info = msg.getInfo()
            if type(info) = "roAssociativeArray" then scene.inputArgs = info
        end if
    end while
end sub
