' CheeseTV for Roku - registry, welcome screen, Playlist management and the Add playlist form.
' MIT License, (c) 2026 CheeseTV. Nothing is pre-filled: the user types their own provider details.

' ---------------- registry ----------------
function regSec() as object
    if m.sec = invalid then m.sec = CreateObject("roRegistrySection", "CheeseTV")
    return m.sec
end function

function regRead(key as string, default as dynamic) as dynamic
    sec = regSec()
    if not sec.Exists(key) then return default
    v = ParseJson(sec.Read(key))
    if v = invalid then return default
    return v
end function

function regWrite(key as string, value as dynamic) as boolean
    sec = regSec()
    sec.Write(key, FormatJson(value))
    return sec.Flush()
end function

sub regDelete(key as string)
    sec = regSec()
    sec.Delete(key)
    sec.Flush()
end sub

sub loadState()
    m.plists = regRead("playlists", [])
    if type(m.plists) <> "roArray" then m.plists = []
    m.settings = regRead("settings", { fmt: "auto" })
    if type(m.settings) <> "roAssociativeArray" then m.settings = { fmt: "auto" }
    sec = regSec()
    m.activeId = ""
    if sec.Exists("active") then m.activeId = sec.Read("active")
    ' migrate the single login saved by CheeseTV for Roku 1.x
    if m.plists.count() = 0 and sec.Exists("account")
        a = ParseJson(sec.Read("account"))
        if a <> invalid and type(a) = "roAssociativeArray"
            a.id = "p1"
            a.name = defaultName(a)
            m.plists.push(a)
            m.activeId = "p1"
            regWrite("playlists", m.plists)
            sec.Write("active", "p1")
        end if
        sec.Delete("account")
        sec.Flush()
    end if
end sub

function activePlaylist() as dynamic
    for each p in m.plists
        if p.id = m.activeId then return p
    end for
    return invalid
end function

function defaultName(p as object) as string
    if p.type = "xtream"
        h = xBase(p)
        h = h.Replace("http://", "").Replace("https://", "")
        c = Instr(1, h, ":")
        if c > 0 then h = Left(h, c - 1)
        if h <> "" then return h
        return "Xtream"
    end if
    return "Playlist"
end function

function newPlaylistId() as string
    n = 1
    while true
        id = "p" + n.ToStr()
        used = false
        for each p in m.plists
            if p.id = id then used = true
        end for
        if not used then return id
        n = n + 1
    end while
    return "p1"
end function

' ---------------- welcome ----------------
sub showWelcome()
    hideAll()
    m.screen = "welcome"
    m.welcomeGroup.visible = true
    m.welcomeBtn.setFocus(true)
    markLaunched()
end sub

sub onWelcomeSelected()
    openForm(invalid)
end sub

' ---------------- connect ----------------
sub connect(p as object)
    m.acc = p
    m.activeId = p.id
    regSec().Write("active", p.id)
    regSec().Flush()
    m.connected = false
    m.m3u = invalid
    m.epgCache = {}
    m.epgCount = 0
    m.searchRoot = invalid
    m.searchQ = ""
    setLoading(true, "Loading your channels…", "This can take a minute for big Xtream accounts.")
    m.loginReq = api("login", {}, "onLogin")
end sub

sub onLogin(ev as object)
    res = ev.getData()
    if res.id <> m.loginReq then return
    if not res.ok
        setLoading(false)
        if m.formPending <> invalid
            formLoginFailed(res.error)
        else
            showPlaylists("Couldn't add playlist: " + res.error)
        end if
        return
    end if
    if m.formPending <> invalid then formLoginOk()
    m.acctInfo = res.data.info
    m.srvOffset = 0
    if res.data.srvOffset <> invalid then m.srvOffset = res.data.srvOffset
    if m.acc.type = "m3u"
        m.m3u = res.data
        m.cats = { live: res.data.live.cats, movies: res.data.movies.cats, series: res.data.series.cats }
        enterMain()
    else
        m.catsReq = api("allCats", {}, "onAllCats")
    end if
end sub

sub onAllCats(ev as object)
    res = ev.getData()
    if res.id <> m.catsReq then return
    m.cats = res.data
    enterMain()
end sub

' ---------------- Playlist management ----------------
sub showPlaylists(msg as string)
    hideAll()
    m.screen = "playlists"
    m.plGroup.visible = true
    m.plMsg.text = msg
    root = CreateObject("roSGNode", "ContentNode")
    a = root.createChild("ContentNode")
    a.title = "Add playlist"
    a.description = "Add a playlist from a link or sign in to an Xtream Codes server"
    a.addFields({ icon: "+", arrow: "1", section: "", tone: "accent", sid: "*add" })
    if m.plists.count() = 0
        e = root.createChild("ContentNode")
        e.title = "No playlists yet. Add one to start watching."
        e.description = ""
        e.addFields({ icon: "•", arrow: "", section: "Your playlists", tone: "", sid: "*none" })
    end if
    first = true
    for each p in m.plists
        c = root.createChild("ContentNode")
        c.title = p.name
        d = ""
        if p.type = "xtream" then d = "Xtream  ·  " + xBase(p) + "  ·  " + toStr(p.user) else d = "M3U  ·  " + Left(toStr(p.url), 80)
        if p.id = m.activeId and m.connected then d = "● In use  ·  " + d
        c.description = d
        sec = ""
        if first then sec = "Your playlists"
        first = false
        tone = ""
        if p.id = m.activeId and m.connected then tone = "accent"
        c.addFields({ icon: "▶", arrow: "", section: sec, tone: tone, sid: p.id })
    end for
    m.plList.content = root
    m.plList.jumpToItem = 0
    if m.plists.count() > 0 then m.plList.jumpToItem = 1
    m.plList.setFocus(true)
    markLaunched()
end sub

function plFocused() as dynamic
    c = m.plList.content.getChild(m.plList.itemFocused)
    if c = invalid then return invalid
    for each p in m.plists
        if p.id = c.sid then return p
    end for
    return invalid
end function

sub onPlSelected()
    c = m.plList.content.getChild(m.plList.itemSelected)
    if c = invalid then return
    if c.sid = "*add" or c.sid = "*none"
        openForm(invalid)
        return
    end if
    p = plFocused()
    if p <> invalid then connect(p)
end sub

sub plOptionsChoice(idx as integer)
    p = m.plTarget
    if p = invalid then return
    if idx = 0
        openForm(p)
    else if idx = 1
        showChoice("plDelete", "Delete playlist?", ["Delete " + Chr(34) + p.name + Chr(34) + "? Its favorites and Continue Watching are removed too."], ["Delete", "Cancel"])
    end if
end sub

sub plDeleteChoice(idx as integer)
    if idx <> 0 then return
    p = m.plTarget
    out = []
    for each q in m.plists
        if q.id <> p.id then out.push(q)
    end for
    m.plists = out
    regWrite("playlists", m.plists)
    regDelete("fav_" + p.id)
    regDelete("rec_" + p.id)
    if p.id = m.activeId
        m.activeId = ""
        regDelete("active")
        m.acc = invalid
        m.connected = false
        m.m3u = invalid
    end if
    if m.plists.count() = 0 then showWelcome() else showPlaylists("Playlist deleted.")
end sub

function playlistsKey(key as string) as boolean
    if key = "options"
        p = plFocused()
        if p <> invalid
            m.plTarget = p
            showChoice("plOptions", p.name, ["What do you want to do with this playlist?"], ["Edit", "Delete", "Cancel"])
        end if
        return true
    else if key = "back"
        if m.connected
            showTab("settings", true)
        else if activePlaylist() <> invalid
            connect(activePlaylist())
        else
            askExit()
        end if
        return true
    end if
    return false
end function

' ---------------- Add / edit playlist form ----------------
sub openForm(p as dynamic)
    m.formReturn = m.screen
    if p = invalid
        m.form = { mode: "add", id: "", src: "xtream", name: "", server: "", user: "", pass: "", url: "" }
    else
        m.form = { mode: "edit", id: p.id, src: p.type, name: toStr(p.name), server: toStr(p.server), user: toStr(p.user), pass: toStr(p.pass), url: toStr(p.url) }
    end if
    hideAll()
    m.screen = "form"
    m.formGroup.visible = true
    m.formMsg.text = ""
    if p = invalid then m.formTitle.text = "Add playlist" else m.formTitle.text = "Edit playlist"
    buildForm(0)
    m.formList.setFocus(true)
end sub

function formRow(root as object, id as string, title as string, value as string, placeholder as string) as object
    c = root.createChild("ContentNode")
    c.title = title
    if value <> "" then c.description = value else c.description = placeholder
    c.addFields({ icon: "", arrow: "", section: "", tone: "", sid: id })
    return c
end function

sub buildForm(focus as integer)
    f = m.form
    root = CreateObject("roSGNode", "ContentNode")
    src = "Xtream  -  Sign in to an Xtream Codes server"
    if f.src = "m3u" then src = "M3U  -  Add a playlist from a link"
    s = formRow(root, "src", "Choose a source", src, "")
    s.arrow = "1"
    if f.src = "xtream"
        formRow(root, "name", "Playlist name (optional)", f.name, "Uses the server name if empty")
        formRow(root, "server", "Server URL (e.g. http://host:8080)", f.server, "Press OK to type")
        formRow(root, "user", "Username", f.user, "Press OK to type")
        pw = ""
        if f.pass <> "" then pw = String(Len(f.pass), "•")
        formRow(root, "pass", "Password", pw, "Press OK to type")
        m.formWarn.visible = true
    else
        formRow(root, "name", "Playlist name", f.name, "Press OK to type")
        formRow(root, "url", "Playlist URL", f.url, "http:// or https:// link from your provider")
        m.formWarn.visible = false
    end if
    b = formRow(root, "go", "Subscribe", "", "")
    b.tone = "accent"
    b.icon = "✓"
    m.formList.content = root
    m.formList.jumpToItem = focus
end sub

sub onFormSelected()
    c = m.formList.content.getChild(m.formList.itemSelected)
    if c = invalid then return
    id = c.sid
    f = m.form
    m.formMsg.text = ""
    if id = "src"
        if f.src = "xtream" then f.src = "m3u" else f.src = "xtream"
        buildForm(0)
    else if id = "name"
        askText("form:name", c.title, "", f.name, "generic")
    else if id = "server"
        t = f.server
        if t = "" then t = "http://"
        askText("form:server", "Server URL (e.g. http://host:8080)", "Include the port if your provider gave you one.", t, "url")
    else if id = "user"
        askText("form:user", "Username", "", f.user, "generic")
    else if id = "pass"
        askText("form:pass", "Password", "", f.pass, "password")
    else if id = "url"
        t = f.url
        if t = "" then t = "http://"
        askText("form:url", "Playlist URL", "Enter the full playlist link from your provider.", t, "url")
    else if id = "go"
        submitForm()
    end if
end sub

sub formFieldEntered(field as string, txt as string)
    f = m.form
    f[field] = txt
    buildForm(m.formList.itemFocused)
    ' move to the next field automatically, like pressing Next on a keyboard
    n = m.formList.content.getChildCount()
    nx = m.formList.itemFocused + 1
    if nx < n then m.formList.jumpToItem = nx
end sub

function validUrl(u as string) as boolean
    l = LCase(u)
    return (Left(l, 7) = "http://" and Len(l) > 7) or (Left(l, 8) = "https://" and Len(l) > 8)
end function

sub submitForm()
    f = m.form
    if f.src = "xtream"
        if f.server.Trim() = "" or f.server.Trim() = "http://"
            m.formMsg.text = "blank url"
            return
        end if
        if f.user.Trim() = "" or f.pass = ""
            m.formMsg.text = "Username and password are required"
            return
        end if
        p = { type: "xtream", server: f.server.Trim(), user: f.user.Trim(), pass: f.pass, name: f.name.Trim() }
        if p.name = "" then p.name = defaultName(p)
    else
        if f.name.Trim() = ""
            m.formMsg.text = "playlist name is empty"
            return
        end if
        if not validUrl(f.url.Trim())
            m.formMsg.text = "malformed url (" + f.url + ")"
            return
        end if
        p = { type: "m3u", url: f.url.Trim(), name: f.name.Trim() }
    end if
    if f.mode = "edit" then p.id = f.id else p.id = newPlaylistId()
    m.formPending = p
    m.acc = p
    m.connected = false
    m.m3u = invalid
    sub_ = ""
    if p.type = "xtream" then sub_ = "it may take much more time"
    setLoading(true, "Subscribing…", sub_)
    m.loginReq = api("login", {}, "onLogin")
end sub

sub formLoginOk()
    p = m.formPending
    m.formPending = invalid
    out = []
    replaced = false
    for each q in m.plists
        if q.id = p.id
            out.push(p)
            replaced = true
        else
            out.push(q)
        end if
    end for
    if not replaced then out.push(p)
    m.plists = out
    regWrite("playlists", m.plists)
    m.activeId = p.id
    regSec().Write("active", p.id)
    regSec().Flush()
    setLoading(true, "Loading your channels…", "This can take a minute for big Xtream accounts.")
    showToast("Playlist added")
end sub

sub formLoginFailed(err as string)
    m.formErr = err
    m.acc = activePlaylist()
    if m.formPending <> invalid and m.acc <> invalid and m.acc.id = m.formPending.id then m.acc = invalid
    showChoice("addFailed", "Couldn't add playlist", [err, "The playlist could not be loaded. Check the details and try again."], ["Try again", "OK"])
end sub

sub addFailedChoice(idx as integer)
    m.formPending = invalid
    if idx = 0
        submitForm()
    else
        m.formMsg.text = m.formErr
        m.formList.setFocus(true)
    end if
end sub

function formKey(key as string) as boolean
    if key = "back"
        m.formPending = invalid
        if m.formReturn = "playlists"
            showPlaylists("")
        else if m.formReturn = "welcome"
            showWelcome()
        else if m.connected
            showTab("settings", true)
        else if activePlaylist() <> invalid
            connect(activePlaylist())
        else
            showWelcome()
        end if
        return true
    end if
    return false
end function
