' CheeseTV home tile. MIT License, (c) 2026 CheeseTV.
sub init()
    m.bg = m.top.findNode("bg")
    m.icon = m.top.findNode("icon")
    m.lbl = m.top.findNode("lbl")
end sub
sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.lbl.text = c.title
    m.icon.uri = c.HDPosterUrl
end sub
sub onFocus()
    f = m.top.focusPercent
    if not m.top.gridHasFocus then f = 0
    if f > 0.5
        m.bg.color = "0xF5C242FF"
        m.lbl.color = "0x0B1630FF"
        m.icon.blendColor = "0x0B1630FF"
    else
        m.bg.color = "0x16285AFF"
        m.lbl.color = "0xF5C242FF"
        m.icon.blendColor = "0xFFFFFFFF"
    end if
end sub
