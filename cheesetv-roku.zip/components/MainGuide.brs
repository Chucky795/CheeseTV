' CheeseTV for Roku - Guide (TimeGrid): category chips, day picker, lazy per-channel EPG, catch-up.
' MIT License, (c) 2026 CheeseTV.

sub initGuide()
    m.dayOffsets = [-2, -1, 0, 1, 2, 3, 4]
    tg = m.timeGrid
    tg.setFields({
        maxDays: 7
        duration: 7200
        numRows: 6
        channelInfoWidth: 330
        itemSize: [1808, 112]
        channelInfoComponentName: "GuideChannel"
        channelNoDataText: "No guide information"
        loadingDataText: "Loading…"
        programTitleColor: "0xF4F6FBFF"
        programTitleFocusedColor: "0x1A1300FF"
        programBackgroundBitmapUri: "pkg:/images/cell.9.png"
        focusBitmapUri: "pkg:/images/cellf.9.png"
        nowBarBlendColor: "0xF5C242FF"
        timeLabelColor: "0xAEB7CCFF"
        pastTimeScreenBlendColor: "0x0B1630FF"
        fillProgramGaps: true
        automaticLoadingDataFeedback: false
    })
    tg.observeField("programFocusedDetails", "onProgramFocused")
    tg.observeField("programSelected", "onProgramSelected")
    tg.observeField("channelFocused", "onGuideChannelFocused")
    m.gChips.observeField("rowItemFocused", "onGChipFocused")
    m.gChips.observeField("rowItemSelected", "onGChipSelected")
    m.dayGrid.observeField("itemSelected", "onDaySelected")
    m.guideTimer.observeField("fire", "onGuideTimer")
    days = CreateObject("roSGNode", "ContentNode")
    for each d in m.dayOffsets
        c = days.createChild("ContentNode")
        c.title = dayLabelX(d)
        c.addFields({ chip: true, sel: (d = 0), off: d })
    end for
    m.dayGrid.content = days
    m.guideRoot = invalid
    m.guideBusy = false
    m.guideLaunching = false
end sub

function dayLabelX(d as integer) as string
    if d = -1 then return "Yesterday"
    if d < -1
        dd = CreateObject("roDateTime")
        dd.FromSeconds(localMidnight(d) + 43200)
        return Left(dd.GetWeekday(), 3) + " " + dd.GetDayOfMonth().ToStr()
    end if
    return dayLabel(d)
end function

sub showGuide()
    m.guideGroup.visible = true
    if not isX()
        m.timeGrid.visible = false
        m.gChips.visible = false
        m.dayGrid.visible = false
        m.guideMsg.visible = true
        m.guideMsg.text = "No program guide (EPG) for these channels yet." + Chr(10) + "On Roku the guide works with Xtream Codes logins. Add your Xtream login in Settings > Playlist management."
        m.gTitle.text = "Guide"
        m.gTime.text = ""
        m.gBadge.text = ""
        return
    end if
    m.top.signalBeacon("EPGLaunchInitiate")
    m.guideLaunching = true
    m.timeGrid.visible = true
    m.gChips.visible = true
    m.dayGrid.visible = true
    m.guideMsg.visible = false
    t = nowSecs()
    m.timeGrid.contentStartTime = localMidnight(m.dayOffsets[0])
    chips = CreateObject("roSGNode", "ContentNode")
    row = chips.createChild("ContentNode")
    f = row.createChild("ContentNode")
    f.title = "★ Favorites"
    f.addFields({ chip: true, sel: false, catId: "*fav" })
    for each c in m.cats.live
        ch = row.createChild("ContentNode")
        ch.title = c.name
        ch.addFields({ chip: true, sel: false, catId: c.id })
    end for
    m.gChips.content = chips
    start = 1
    if row.getChildCount() = 1 then start = 0
    m.gChips.jumpToRowItem = [0, start]
    setDaySel(2)
    loadGuideCat(start)
end sub

sub guideFocus()
    if m.timeGrid.visible and m.guideRoot <> invalid and m.guideRoot.getChildCount() > 0
        m.timeGrid.setFocus(true)
    else if m.gChips.visible
        m.gChips.setFocus(true)
    else
        m.nav.setFocus(true)
    end if
end sub

sub setDaySel(i as integer)
    c = m.dayGrid.content
    for j = 0 to c.getChildCount() - 1
        c.getChild(j).sel = (j = i)
    end for
    m.dayGrid.jumpToItem = i
end sub

sub onGChipFocused()
    m.guideTimer.control = "stop"
    m.guideTimer.control = "start"
end sub

sub onGuideTimer()
    rf = m.gChips.rowItemFocused
    if rf = invalid or rf.count() < 2 then return
    if rf[1] <> m.gChipSel then loadGuideCat(rf[1])
end sub

sub onGChipSelected()
    rs = m.gChips.rowItemSelected
    if rs[1] <> m.gChipSel then loadGuideCat(rs[1])
    guideFocus()
end sub

sub loadGuideCat(i as integer)
    m.gChipSel = i
    row = m.gChips.content.getChild(0)
    for j = 0 to row.getChildCount() - 1
        row.getChild(j).sel = (j = i)
    end for
    chip = row.getChild(i)
    if chip = invalid then return
    if chip.catId = "*fav"
        list = CreateObject("roSGNode", "ContentNode")
        for each r in m.favs
            if r.k = "live"
                it = recToNode(r, m.acc, fmtPref(), list)
                it.fav = true
            end if
        end for
        setGuideChannels(list)
    else
        m.gTitle.text = "Loading…"
        m.guideReq = api("items", { mode: "live", catId: chip.catId, limit: 300 }, "onGuideItems")
    end if
end sub

sub onGuideItems(ev as object)
    res = ev.getData()
    if res.id <> m.guideReq then return
    markFavs(res.data)
    setGuideChannels(res.data)
end sub

sub setGuideChannels(list as object)
    m.guideList = list
    root = CreateObject("roSGNode", "ContentNode")
    m.guideIdx = {}
    n = list.getChildCount()
    for i = 0 to n - 1
        it = list.getChild(i)
        ch = root.createChild("ContentNode")
        ch.title = it.title
        ch.HDPosterUrl = it.HDPosterUrl
        ch.addFields({ sid: it.sid, st: "idle", archive: it.archive, fav: it.fav })
        m.guideIdx[it.sid] = i
    end for
    m.guideRoot = root
    m.guideBusy = false
    m.guideFocusCh = 0
    if n = 0
        m.timeGrid.content = root
        m.gTitle.text = "No live channels"
        m.gTime.text = "Press * on any channel to add it to Favorites."
        m.gBadge.text = ""
        if m.timeGrid.hasFocus() then m.gChips.setFocus(true)
        return
    end if
    m.timeGrid.content = root
    t = nowSecs()
    m.timeGrid.leftEdgeTargetTime = t - (t mod 1800)
    setDaySel(2)
    m.gTitle.text = list.getChild(0).title
    m.gTime.text = ""
    m.gBadge.text = ""
    guideLoadAround(0)
end sub

sub onGuideChannelFocused()
    m.guideFocusCh = m.timeGrid.channelFocused
    guideLoadAround(m.guideFocusCh)
end sub

sub guideLoadAround(f as integer)
    if m.guideBusy or m.guideRoot = invalid then return
    sids = []
    for i = f - 1 to f + 8
        ch = m.guideRoot.getChild(i)
        if ch <> invalid and ch.st = "idle" and ch.sid <> ""
            ch.st = "loading"
            sids.push(ch.sid)
        end if
    end for
    if sids.count() = 0 then return
    m.guideBusy = true
    m.guideEpgReq = api("epgDay", { sids: sids, fromTs: localMidnight(m.dayOffsets[0]), toTs: localMidnight(m.dayOffsets[m.dayOffsets.count() - 1] + 1) }, "onGuideEpg")
    m.guideEpgRoot = m.guideRoot
end sub

sub onGuideEpg(ev as object)
    res = ev.getData()
    if res.id <> m.guideEpgReq then return
    m.guideBusy = false
    root = m.guideEpgRoot
    if root = invalid or m.guideRoot = invalid or not root.isSameNode(m.guideRoot) then return
    mp = res.data.map
    for each sid in mp
        idx = m.guideIdx[sid]
        if idx <> invalid
            ch = root.getChild(idx)
            progs = []
            for each e in mp[sid]
                p = CreateObject("roSGNode", "ContentNode")
                p.title = e.t
                p.PlayStart = e.s
                p.PlayDuration = e.e - e.s
                progs.push(p)
            end for
            if progs.count() > 0 then ch.appendChildren(progs)
            ch.st = "loaded"
            ' keep the now/next cache in sync for tiles and the player overlay
            m.epgCache[sid] = mp[sid]
        end if
    end for
    evictGuide()
    if m.guideLaunching
        m.guideLaunching = false
        m.top.signalBeacon("EPGLaunchComplete")
    end if
    onProgramFocused()
    guideLoadAround(m.guideFocusCh)
end sub

' Keeps memory low on entry-level Rokus: only ~40 channels keep their programme lists.
sub evictGuide()
    root = m.guideRoot
    loaded = []
    for i = 0 to root.getChildCount() - 1
        if root.getChild(i).st = "loaded" then loaded.push(i)
    end for
    if loaded.count() <= 40 then return
    f = m.guideFocusCh
    for each i in loaded
        if Abs(i - f) > 25
            ch = root.getChild(i)
            ch.removeChildrenIndex(ch.getChildCount(), 0)
            ch.st = "idle"
        end if
    end for
end sub

function guideFocused() as object
    res = { ch: invalid, item: invalid, prog: invalid, idx: 0 }
    if m.guideRoot = invalid then return res
    d = m.timeGrid.programFocusedDetails
    ci = m.guideFocusCh
    pi = -1
    if d <> invalid and d.focusChannelIndex <> invalid
        ci = d.focusChannelIndex
        pi = d.focusIndex
    end if
    res.idx = ci
    res.ch = m.guideRoot.getChild(ci)
    if m.guideList <> invalid then res.item = m.guideList.getChild(ci)
    if res.ch <> invalid and pi >= 0 then res.prog = res.ch.getChild(pi)
    return res
end function

sub onProgramFocused()
    g = guideFocused()
    if g.ch = invalid then return
    p = g.prog
    now = nowSecs()
    if p = invalid
        m.gTitle.text = g.ch.title
        m.gTime.text = "No guide information"
        m.gBadge.text = ""
        return
    end if
    s = p.PlayStart
    e = s + p.PlayDuration
    m.gTitle.text = p.title
    m.gTime.text = dayLabelForTs(s) + "  " + hhmm(s) + " – " + hhmm(e) + "   ·   " + g.ch.title
    if s <= now and e > now
        m.gBadge.text = "● ON NOW"
    else if e <= now
        if canCatchup(g.ch, s) then m.gBadge.text = "↺ CATCH-UP" else m.gBadge.text = "ENDED"
    else
        m.gBadge.text = "LATER"
    end if
end sub

function dayLabelForTs(ts as integer) as string
    for each d in [-2, -1, 0, 1, 2, 3, 4, 5]
        if ts >= localMidnight(d) and ts < localMidnight(d + 1) then return dayLabelX(d)
    end for
    return ""
end function

function canCatchup(ch as object, startTs as integer) as boolean
    ar = ch.archive
    if ar = invalid or ar <= 0 then return false
    return startTs >= nowSecs() - ar * 86400
end function

sub onProgramSelected()
    g = guideFocused()
    if g.item = invalid then return
    p = g.prog
    now = nowSecs()
    if p = invalid
        playItem(g.item, m.guideList)
        return
    end if
    s = p.PlayStart
    e = s + p.PlayDuration
    if s <= now and e > now
        playItem(g.item, m.guideList)
    else if e <= now
        if canCatchup(g.ch, s)
            playCatchup(g.item, p.title, s, e)
        else
            showToast("Catch-up isn't available for this channel")
        end if
    else
        m.guideWatch = g
        showChoice("future", p.title, ["Starts " + dayLabelForTs(s) + " at " + hhmm(s) + " on " + g.ch.title + "."], ["Watch channel now", "Close"])
    end if
end sub

sub guideWatchFocused()
    g = m.guideWatch
    if g <> invalid and g.item <> invalid then playItem(g.item, m.guideList)
end sub

sub playCatchup(item as object, progTitle as string, s as integer, e as integer)
    cu = catchupUrls(m.acc, item.sid, s, e, m.srvOffset, fmtPref())
    list = CreateObject("roSGNode", "ContentNode")
    rec = { k: "catchup", i: item.sid, t: item.title + " - " + progTitle, g: item.HDPosterUrl, u: cu.url, f: cu.fmt, a: cu.alt, af: cu.altFmt, n: item.num, ar: item.archive }
    it = recToNode(rec, invalid, fmtPref(), list)
    playItem(it, list)
end sub

sub onDaySelected()
    i = m.dayGrid.itemSelected
    setDaySel(i)
    d = m.dayOffsets[i]
    if d = 0
        t = nowSecs()
        m.timeGrid.leftEdgeTargetTime = t - (t mod 1800)
    else
        m.timeGrid.leftEdgeTargetTime = localMidnight(d) + 18 * 3600
    end if
    guideFocus()
end sub

function guideKey(key as string) as boolean
    if key = "options" and m.timeGrid.hasFocus()
        g = guideFocused()
        if g.item <> invalid
            toggleFav(g.item)
            if g.ch <> invalid then g.ch.fav = g.item.fav
        end if
        return true
    end if
    if m.timeGrid.hasFocus()
        if key = "up"
            m.dayGrid.setFocus(true)
            return true
        else if key = "back"
            m.gChips.setFocus(true)
            return true
        end if
    else if m.dayGrid.hasFocus()
        if key = "up"
            m.gChips.setFocus(true)
            return true
        else if key = "down"
            guideFocus()
            return true
        else if key = "back"
            m.nav.setFocus(true)
            return true
        end if
    else if m.gChips.hasFocus()
        if key = "up" or key = "back"
            m.nav.setFocus(true)
            return true
        else if key = "down"
            m.dayGrid.setFocus(true)
            return true
        end if
    end if
    return false
end function
