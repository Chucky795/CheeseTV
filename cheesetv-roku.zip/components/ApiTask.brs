' CheeseTV for Roku - network/parsing task. MIT License, (c) 2026 CheeseTV.
sub init()
    m.top.functionName = "runTask"
end sub

sub runTask()
    req = m.top.request
    res = { id: req.id, kind: req.kind, ok: false, error: "", data: invalid }
    acc = req.account
    k = req.kind
    if k = "login"
        if acc.type = "xtream"
            j = getJson(xApi(acc, ""), 20000)
            if j = invalid
                res.error = "Could not reach the server"
            else if j.user_info = invalid or toStr(j.user_info.auth) <> "1"
                res.error = "Login failed: check server, username and password"
            else
                ui = j.user_info
                info = "Account " + toStr(ui.status)
                if toStr(ui.exp_date) <> "" and toStr(ui.exp_date) <> "null"
                    d = CreateObject("roDateTime")
                    d.FromSeconds(toStr(ui.exp_date).ToInt())
                    info = info + " - expires " + d.AsDateString("short-date")
                end if
                res.ok = true
                res.data = { info: info }
            end if
        else
            txt = httpGet(acc.url, 90000)
            if txt = invalid
                res.error = "Could not download the playlist"
            else if Instr(1, txt, "#EXTINF") = 0
                res.error = "This does not look like an M3U playlist"
            else
                res.ok = true
                res.data = parseM3U(txt)
            end if
        end if
    else if k = "cats"
        actions = { live: "get_live_categories", movies: "get_vod_categories", series: "get_series_categories" }
        action = actions[req.mode]
        j = getJson(xApi(acc, "&action=" + action), 30000)
        root = CreateObject("roSGNode", "ContentNode")
        if req.mode = "live" then addCat(root, "*", "All channels")
        if j <> invalid and type(j) = "roArray"
            for each c in j
                addCat(root, toStr(c.category_id), toStr(c.category_name))
            end for
            res.ok = true
        else
            res.error = "Could not load categories"
        end if
        res.data = root
    else if k = "items"
        actions = { live: "get_live_streams", movies: "get_vod_streams", series: "get_series" }
        action = actions[req.mode]
        extra = "&action=" + action
        if req.catId <> "*" then extra = extra + "&category_id=" + esc(req.catId)
        j = getJson(xApi(acc, extra), 45000)
        root = CreateObject("roSGNode", "ContentNode")
        if j <> invalid and type(j) = "roArray"
            base = xBase(acc)
            up = "/" + esc(acc.user) + "/" + esc(acc.pass) + "/"
            n = 0
            for each s in j
                n = n + 1
                if n > 20000 then exit for
                it = root.createChild("ContentNode")
                it.title = toStr(s.name)
                if req.mode = "live"
                    it.HDPosterUrl = toStr(s.stream_icon)
                    it.url = base + "/live" + up + toStr(s.stream_id) + ".m3u8"
                    it.streamFormat = "hls"
                    it.Live = true
                    it.addFields({ kind: "live", sid: toStr(s.stream_id) })
                else if req.mode = "movies"
                    ext = toStr(s.container_extension)
                    if ext = "" then ext = "mp4"
                    it.HDPosterUrl = toStr(s.stream_icon)
                    it.url = base + "/movie" + up + toStr(s.stream_id) + "." + ext
                    it.streamFormat = fmtFor(ext)
                    if toStr(s.rating) <> "" then it.description = "Rating: " + toStr(s.rating)
                    it.addFields({ kind: "movie", sid: toStr(s.stream_id) })
                else
                    it.HDPosterUrl = toStr(s.cover)
                    it.description = toStr(s.plot)
                    it.addFields({ kind: "series", sid: toStr(s.series_id) })
                end if
            end for
            res.ok = true
        else
            res.error = "Could not load this category"
        end if
        res.data = root
    else if k = "episodes"
        j = getJson(xApi(acc, "&action=get_series_info&series_id=" + esc(req.seriesId)), 45000)
        root = CreateObject("roSGNode", "ContentNode")
        if j <> invalid and j.episodes <> invalid
            base = xBase(acc)
            up = "/" + esc(acc.user) + "/" + esc(acc.pass) + "/"
            eps = j.episodes
            seasons = []
            if type(eps) = "roAssociativeArray"
                keys = []
                for each key in eps
                    keys.push(key)
                end for
                sortNumeric(keys)
                for each key in keys
                    seasons.push(eps[key])
                end for
            else if type(eps) = "roArray"
                seasons = eps
            end if
            for each season in seasons
                if type(season) = "roArray"
                    for each e in season
                        ext = toStr(e.container_extension)
                        if ext = "" then ext = "mp4"
                        it = root.createChild("ContentNode")
                        it.title = "S" + toStr(e.season) + " E" + toStr(e.episode_num) + " - " + toStr(e.title)
                        it.url = base + "/series" + up + toStr(e.id) + "." + ext
                        it.streamFormat = fmtFor(ext)
                        if e.info <> invalid and type(e.info) = "roAssociativeArray"
                            it.HDPosterUrl = toStr(e.info.movie_image)
                            it.description = toStr(e.info.plot)
                        end if
                        it.addFields({ kind: "episode", sid: toStr(e.id) })
                    end for
                end if
            end for
            res.ok = root.getChildCount() > 0
            if not res.ok then res.error = "No episodes found"
        else
            res.error = "Could not load episodes"
        end if
        res.data = root
    else if k = "epg"
        j = getJson(xApi(acc, "&action=get_short_epg&limit=2&stream_id=" + esc(req.streamId)), 15000)
        txt = ""
        if j <> invalid and j.epg_listings <> invalid and type(j.epg_listings) = "roArray"
            for each e in j.epg_listings
                line = hhmm(toStr(e.start_timestamp)) + "-" + hhmm(toStr(e.stop_timestamp)) + "  " + b64(toStr(e.title))
                if txt = "" then txt = "Now: " + line else txt = txt + Chr(10) + "Next: " + line
            end for
        end if
        res.ok = true
        res.data = { text: txt, streamId: req.streamId }
    end if
    m.top.response = res
end sub

' ---------- helpers ----------
sub addCat(root as object, id as string, name as string)
    c = root.createChild("ContentNode")
    c.title = name
    c.addFields({ catId: id })
end sub

sub sortNumeric(a as object)
    ' simple insertion sort by integer value
    for i = 1 to a.count() - 1
        v = a[i]
        j = i - 1
        while j >= 0 and a[j].ToInt() > v.ToInt()
            a[j + 1] = a[j]
            j = j - 1
        end while
        a[j + 1] = v
    end for
end sub

function toStr(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInt" or t = "roInteger" or t = "Integer" or t = "LongInteger" or t = "roLongInteger" then return StrI(v).Trim()
    if t = "roFloat" or t = "Float" or t = "roDouble" or t = "Double"
        if v = Int(v) then return StrI(Int(v)).Trim()
        return Str(v).Trim()
    end if
    if t = "roBoolean" or t = "Boolean"
        if v then return "true"
        return "false"
    end if
    return ""
end function

function esc(s as string) as string
    return CreateObject("roUrlTransfer").Escape(s)
end function

function trimStr(s as string) as string
    return s.Trim()
end function

function xBase(acc as object) as string
    s = trimStr(acc.server)
    low = LCase(s)
    if Left(low, 7) <> "http://" and Left(low, 8) <> "https://" then s = "http://" + s
    r = CreateObject("roRegex", "/(player_api\.php|get\.php|panel_api\.php).*$", "i")
    s = r.Replace(s, "")
    while Right(s, 1) = "/"
        s = Left(s, Len(s) - 1)
    end while
    return s
end function

function xApi(acc as object, extra as string) as string
    return xBase(acc) + "/player_api.php?username=" + esc(acc.user) + "&password=" + esc(acc.pass) + extra
end function

function fmtFor(ext as string) as string
    e = LCase(ext)
    if e = "m3u8" or e = "m3u" then return "hls"
    if e = "mkv" then return "mkv"
    if e = "mpd" then return "dash"
    if e = "mov" then return "mov"
    if e = "m4v" then return "m4v"
    if e = "mp3" then return "mp3"
    return "mp4"
end function

function hhmm(ts as string) as string
    if ts = "" then return ""
    d = CreateObject("roDateTime")
    d.FromSeconds(ts.ToInt())
    d.ToLocalTime()
    h = d.GetHours()
    mi = d.GetMinutes()
    hs = StrI(h).Trim()
    ms = StrI(mi).Trim()
    if h < 10 then hs = "0" + hs
    if mi < 10 then ms = "0" + ms
    return hs + ":" + ms
end function

function b64(s as string) as string
    if s = "" then return ""
    ba = CreateObject("roByteArray")
    ba.FromBase64String(s)
    return ba.ToAsciiString()
end function

function httpGet(url as string, timeoutMs as integer) as dynamic
    ut = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    ut.SetMessagePort(port)
    ut.SetUrl(url)
    ut.SetCertificatesFile("common:/certs/ca-bundle.crt")
    ut.InitClientCertificates()
    ut.EnableEncodings(true)
    ut.RetainBodyOnError(false)
    ut.AddHeader("User-Agent", "CheeseTV-Roku/1.0")
    if not ut.AsyncGetToString() then return invalid
    msg = wait(timeoutMs, port)
    if type(msg) = "roUrlEvent"
        code = msg.GetResponseCode()
        if code >= 200 and code < 300 then return msg.GetString()
        return invalid
    end if
    ut.AsyncCancel()
    return invalid
end function

function getJson(url as string, timeoutMs as integer) as dynamic
    txt = httpGet(url, timeoutMs)
    if txt = invalid then return invalid
    return ParseJson(txt)
end function

' Rewrites Xtream-style M3U links (http://host/user/pass/123 or .ts) to HLS, which Roku can play.
function rokuUrl(url as string) as object
    r = CreateObject("roRegex", "^(https?://[^/]+)/(live/)?([^/]+)/([^/]+)/([0-9]+)(\.ts)?$", "i")
    mm = r.Match(url)
    if mm.count() > 0 then return { url: mm[1] + "/live/" + mm[3] + "/" + mm[4] + "/" + mm[5] + ".m3u8", fmt: "hls" }
    low = LCase(url)
    q = Instr(1, low, "?")
    if q > 0 then low = Left(low, q - 1)
    dot = 0
    for i = Len(low) to 1 step -1
        ch = Mid(low, i, 1)
        if ch = "." then
            dot = i
            exit for
        end if
        if ch = "/" then exit for
    end for
    ext = ""
    if dot > 0 then ext = Mid(low, dot + 1)
    if ext = "" or ext = "ts" then return { url: url, fmt: "hls" }
    return { url: url, fmt: fmtFor(ext) }
end function

function rokuUrlPlain(url as string) as string
    low = LCase(url)
    if Instr(1, low, ".m3u8") > 0 then return "hls"
    if Instr(1, low, ".mkv") > 0 then return "mkv"
    if Instr(1, low, ".mp4") > 0 then return "mp4"
    return "hls"
end function

function parseM3U(text as string) as object
    q = Chr(34)
    attrRx = CreateObject("roRegex", "([A-Za-z0-9_-]+)=" + q + "([^" + q + "]*)" + q, "")
    lines = text.Tokenize(Chr(10))
    out = {}
    for each mode in ["live", "movies", "series"]
        out[mode] = { cats: CreateObject("roSGNode", "ContentNode"), lists: [], index: {}, count: 0 }
    end for
    cur = invalid
    total = 0
    for each raw in lines
        l = raw.Trim()
        if l = ""
            ' skip
        else if Left(l, 7) = "#EXTINF"
            cur = { name: "Channel", group: "Uncategorized", logo: "" }
            lastQ = 0
            for i = Len(l) to 1 step -1
                if Mid(l, i, 1) = q then
                    lastQ = i
                    exit for
                end if
            end for
            c = Instr(lastQ + 1, l, ",")
            if c > 0 then cur.name = Mid(l, c + 1).Trim()
            for each mt in attrRx.MatchAll(l)
                key = LCase(mt[1])
                if key = "group-title" and mt[2] <> "" then cur.group = mt[2]
                if key = "tvg-logo" then cur.logo = mt[2]
            end for
        else if Left(l, 1) = "#"
            ' other directives ignored
        else if cur <> invalid
            total = total + 1
            if total > 30000 then exit for
            low = LCase(l)
            mode = "live"
            kind = "live"
            if Instr(1, low, "/movie/") > 0 then
                mode = "movies"
                kind = "movie"
            else if Instr(1, low, "/series/") > 0 then
                mode = "series"
                kind = "episode"
            end if
            bucket = out[mode]
            idx = bucket.index[cur.group]
            if idx = invalid
                idx = bucket.lists.count()
                bucket.index[cur.group] = idx
                cn = bucket.cats.createChild("ContentNode")
                cn.title = cur.group
                cn.addFields({ catId: StrI(idx).Trim() })
                bucket.lists.push(CreateObject("roSGNode", "ContentNode"))
            end if
            it = bucket.lists[idx].createChild("ContentNode")
            it.title = cur.name
            it.HDPosterUrl = cur.logo
            ru = rokuUrl(l)
            if kind = "live" then it.Live = true
            it.url = ru.url
            it.streamFormat = ru.fmt
            ' keep the original link as a fallback in case the HLS rewrite does not work
            it.addFields({ kind: kind, sid: "", altUrl: l, altFmt: rokuUrlPlain(l) })
            bucket.count = bucket.count + 1
            cur = invalid
        end if
    end for
    res = {}
    for each mode in ["live", "movies", "series"]
        res[mode] = { cats: out[mode].cats, lists: out[mode].lists, count: out[mode].count }
    end for
    res.info = StrI(res.live.count).Trim() + " channels - " + StrI(res.movies.count).Trim() + " movies - " + StrI(res.series.count).Trim() + " episodes"
    return res
end function
