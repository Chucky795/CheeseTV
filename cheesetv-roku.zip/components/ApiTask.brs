' CheeseTV for Roku - network/parsing task. MIT License, (c) 2026 CheeseTV.
sub init()
    m.top.functionName = "runTask"
end sub

sub runTask()
    m.top.response = handleRequest(m.top.request)
end sub

function handleRequest(req as object) as object
    res = { id: req.id, kind: req.kind, ok: false, error: "", data: invalid, tag: req.tag }
    acc = req.account
    pref = toStr(req.pref)
    k = req.kind
    if k = "login"
        doLogin(acc, res)
    else if k = "allCats"
        out = {}
        anyOk = false
        for each mode in ["live", "movies", "series"]
            out[mode] = xCats(acc, mode)
            if out[mode] <> invalid then anyOk = true else out[mode] = []
        end for
        res.ok = anyOk
        if not anyOk then res.error = "Could not load categories"
        res.data = out
    else if k = "items"
        lim = toInt(req.limit)
        if lim <= 0 then lim = 5000
        root = xItems(acc, req.mode, toStr(req.catId), pref, lim)
        if root = invalid
            res.error = "Could not load this category"
            res.data = CreateObject("roSGNode", "ContentNode")
        else
            res.ok = true
            res.data = root
        end if
    else if k = "series"
        d = xSeries(acc, toStr(req.seriesId), pref)
        if d = invalid
            res.error = "Could not load this series"
        else
            res.ok = true
            res.data = d
        end if
    else if k = "epg"
        res.data = { sid: req.sid, list: xShortEpg(acc, toStr(req.sid), 3) }
        res.ok = true
    else if k = "epgBatch"
        mp = {}
        for each sid in req.sids
            lst = xShortEpg(acc, sid, 2)
            mp[sid] = lst
        end for
        res.data = { map: mp }
        res.ok = true
    else if k = "epgDay"
        mp = {}
        for each sid in req.sids
            mp[sid] = xDayEpg(acc, sid, toInt(req.fromTs), toInt(req.toTs))
        end for
        res.data = { map: mp }
        res.ok = true
    else if k = "search"
        res.data = xSearch(acc, toStr(req.q), pref, 60)
        res.ok = res.data <> invalid
        if not res.ok then res.error = "Search failed"
    end if
    ' 2.0.2: Favorites stars are set here, in the task thread, not by a loop on the render thread.
    if (k = "items" or k = "search") and type(req.favKeys) = "roAssociativeArray" and req.favKeys.count() > 0
        markFavKeys(res.data, req.favKeys, k = "search")
    end if
    return res
end function

sub markFavKeys(root as dynamic, keys as object, nested as boolean)
    if root = invalid then return
    for i = 0 to root.getChildCount() - 1
        c = root.getChild(i)
        if nested
            markFavKeys(c, keys, false)
        else if c.hasField("fav") and keys.DoesExist(nodeKey(c))
            c.fav = true
        end if
    end for
end sub

' ---------- login ----------
sub doLogin(acc as object, res as object)
    if acc.type = "xtream"
        j = getJson(xApi(acc, ""), 20000)
        if j = invalid or type(j) <> "roAssociativeArray"
            res.error = "Could not reach the server. Check the server URL and port."
        else if j.user_info = invalid or toStr(j.user_info.auth) <> "1"
            res.error = "Login failed: check the username and password."
        else
            ui = j.user_info
            info = "Account " + toStr(ui.status)
            ex = toInt(ui.exp_date)
            if ex > 0
                d = CreateObject("roDateTime")
                d.FromSeconds(ex)
                info = info + " - expires " + d.AsDateString("short-month-no-weekday")
            end if
            if toStr(ui.max_connections) <> "" then info = info + " - " + toStr(ui.max_connections) + " connection(s)"
            ' server clock offset, needed for catch-up (timeshift) URLs
            off = 0
            si = j.server_info
            if type(si) = "roAssociativeArray"
                tsNow = toInt(si.timestamp_now)
                tn = toStr(si.time_now)
                if tsNow > 0 and Len(tn) >= 16
                    d = CreateObject("roDateTime")
                    d.FromISO8601String(Left(tn, 10) + "T" + Mid(tn, 12) + "Z")
                    off = d.AsSeconds() - tsNow
                    off = Int((off + 450) / 900) * 900
                    if off > 50400 or off < -50400 then off = 0
                end if
            end if
            res.ok = true
            res.data = { info: info, srvOffset: off }
        end if
    else
        txt = httpGet(toStr(acc.url), 120000)
        if txt = invalid
            res.error = "Could not download the playlist. Check the URL."
        else if Instr(1, txt, "#EXTINF") = 0
            res.error = "This does not look like an M3U playlist."
        else
            res.ok = true
            res.data = parseM3U(txt, 40000)
        end if
    end if
end sub

' ---------- Xtream ----------
function xCats(acc as object, mode as string) as dynamic
    actions = { live: "get_live_categories", movies: "get_vod_categories", series: "get_series_categories" }
    j = getJson(xApi(acc, "&action=" + actions[mode]), 30000)
    if j = invalid or type(j) <> "roArray" then return invalid
    out = []
    for each c in j
        if type(c) = "roAssociativeArray" then out.push({ id: toStr(c.category_id), name: toStr(c.category_name) })
    end for
    return out
end function

function streamRec(mode as string, s as object) as object
    if mode = "live"
        rec = { k: "live", i: toStr(s.stream_id), t: toStr(s.name), g: toStr(s.stream_icon), c: toStr(s.category_id) }
        if toStr(s.tv_archive) = "1"
            dd = toInt(s.tv_archive_duration)
            if dd <= 0 then dd = 1
            rec.ar = dd
        end if
        if toStr(s.num) <> "" then rec.n = toStr(s.num)
        return rec
    else if mode = "movies"
        rec = { k: "movie", i: toStr(s.stream_id), t: toStr(s.name), g: toStr(s.stream_icon), c: toStr(s.category_id), x: toStr(s.container_extension) }
        r = toStr(s.rating)
        if r <> "" and r <> "0" then rec.d = "Rating " + r
        return rec
    end if
    return { k: "series", i: toStr(s.series_id), t: toStr(s.name), g: toStr(s.cover), c: toStr(s.category_id), d: toStr(s.plot) }
end function

' Streams of one category as a ContentNode row (lazy per category keeps memory low).
function xItems(acc as object, mode as string, catId as string, pref as string, limit as integer) as dynamic
    actions = { live: "get_live_streams", movies: "get_vod_streams", series: "get_series" }
    extra = "&action=" + actions[mode]
    if catId <> "" and catId <> "*" then extra = extra + "&category_id=" + esc(catId)
    j = getJson(xApi(acc, extra), 45000)
    if j = invalid or type(j) <> "roArray" then return invalid
    root = CreateObject("roSGNode", "ContentNode")
    n = 0
    for each s in j
        if type(s) = "roAssociativeArray"
            n = n + 1
            if n > limit then exit for
            recToNode(streamRec(mode, s), acc, pref, root)
        end if
    end for
    return root
end function

function sortNumeric(a as object) as object
    for i = 1 to a.count() - 1
        v = a[i]
        j = i - 1
        while j >= 0 and a[j].ToInt() > v.ToInt()
            a[j + 1] = a[j]
            j = j - 1
        end while
        a[j + 1] = v
    end for
    return a
end function

function xSeries(acc as object, seriesId as string, pref as string) as dynamic
    j = getJson(xApi(acc, "&action=get_series_info&series_id=" + esc(seriesId)), 45000)
    if j = invalid or type(j) <> "roAssociativeArray" then return invalid
    info = { name: "", plot: "", cover: "", genre: "", year: "", rating: "", cast: "" }
    if type(j.info) = "roAssociativeArray"
        i = j.info
        info.name = toStr(i.name)
        info.plot = toStr(i.plot)
        info.cover = toStr(i.cover)
        info.genre = toStr(i.genre)
        info.year = Left(toStr(i.releaseDate), 4)
        info.rating = toStr(i.rating)
        info.cast = toStr(i.cast)
    end if
    seasons = CreateObject("roSGNode", "ContentNode")
    eps = j.episodes
    keys = []
    lists = {}
    if type(eps) = "roAssociativeArray"
        for each key in eps
            keys.push(key)
            lists[key] = eps[key]
        end for
    else if type(eps) = "roArray"
        ' some panels return a list of seasons (arrays)
        n = 0
        for each season in eps
            n = n + 1
            keys.push(n.ToStr())
            lists[n.ToStr()] = season
        end for
    end if
    sortNumeric(keys)
    for each key in keys
        lst = lists[key]
        if type(lst) = "roArray" and lst.count() > 0
            sn = seasons.createChild("ContentNode")
            sn.title = "Season " + key
            for each e in lst
                if type(e) = "roAssociativeArray"
                    rec = { k: "episode", i: toStr(e.id), x: toStr(e.container_extension), g: info.cover }
                    t = toStr(e.title)
                    rec.t = "E" + toStr(e.episode_num) + " - " + t
                    if type(e.info) = "roAssociativeArray"
                        if toStr(e.info.movie_image) <> "" then rec.g = toStr(e.info.movie_image)
                        rec.d = toStr(e.info.plot)
                        rec.e = toStr(e.info.duration)
                    end if
                    en = recToNode(rec, acc, pref, sn)
                    ' 2.0.4: series / season / episode numbers for Continue watching + sync
                    en.addFields({ ser: seriesId, sea: toInt(key), epn: toInt(e.episode_num) })
                end if
            end for
        end if
    end for
    return { info: info, seasons: seasons }
end function

function epgEntry(e as object) as object
    s = toInt(e.start_timestamp)
    en = toInt(e.stop_timestamp)
    return { t: b64(toStr(e.title)), d: b64(toStr(e.description)), s: s, e: en }
end function

function xShortEpg(acc as object, sid as string, limit as integer) as object
    out = []
    if sid = "" then return out
    j = getJson(xApi(acc, "&action=get_short_epg&limit=" + limit.ToStr() + "&stream_id=" + esc(sid)), 12000)
    if j <> invalid and type(j) = "roAssociativeArray" and type(j.epg_listings) = "roArray"
        now = nowSecs()
        for each e in j.epg_listings
            if type(e) = "roAssociativeArray"
                en = epgEntry(e)
                if en.e > now then out.push(en)
            end if
        end for
    end if
    return out
end function

' Full programme list of one channel (get_simple_data_table), trimmed to [fromTs, toTs].
function xDayEpg(acc as object, sid as string, fromTs as integer, toTs as integer) as object
    out = []
    j = getJson(xApi(acc, "&action=get_simple_data_table&stream_id=" + esc(sid)), 20000)
    lst = invalid
    if j <> invalid and type(j) = "roAssociativeArray" then lst = j.epg_listings
    if type(lst) <> "roArray" or lst.count() = 0
        j = getJson(xApi(acc, "&action=get_short_epg&limit=48&stream_id=" + esc(sid)), 15000)
        if j <> invalid and type(j) = "roAssociativeArray" then lst = j.epg_listings
    end if
    if type(lst) <> "roArray" then return out
    lastEnd = 0
    for each e in lst
        if type(e) = "roAssociativeArray"
            en = epgEntry(e)
            if en.e > fromTs and en.s < toTs and en.e > en.s and en.s >= lastEnd
                out.push({ t: en.t, s: en.s, e: en.e })
                lastEnd = en.e
                if out.count() >= 400 then exit for
            end if
        end if
    end for
    return out
end function

function xSearch(acc as object, q as string, pref as string, cap as integer) as dynamic
    root = CreateObject("roSGNode", "ContentNode")
    ql = LCase(q.Trim())
    if ql = "" then return root
    labels = { live: "Channels", movies: "Movies", series: "Series" }
    actions = { live: "get_live_streams", movies: "get_vod_streams", series: "get_series" }
    for each mode in ["live", "movies", "series"]
        j = getJson(xApi(acc, "&action=" + actions[mode]), 60000)
        row = CreateObject("roSGNode", "ContentNode")
        row.title = labels[mode]
        row.addFields({ mode: mode })
        if j <> invalid and type(j) = "roArray"
            for each s in j
                if type(s) = "roAssociativeArray"
                    if Instr(1, LCase(toStr(s.name)), ql) > 0
                        recToNode(streamRec(mode, s), acc, pref, row)
                        if row.getChildCount() >= cap then exit for
                    end if
                end if
            end for
        end if
        j = invalid
        if row.getChildCount() > 0 then root.appendChild(row)
    end for
    return root
end function

' ---------- M3U ----------
' Rewrites Xtream-style M3U links (http://host/user/pass/123 or .ts) to HLS, which Roku plays best.
function m3uUrl(url as string) as object
    r = CreateObject("roRegex", "^(https?://[^/]+)/(live/)?([^/]+)/([^/]+)/([0-9]+)(\.ts)?$", "i")
    mm = r.Match(url)
    if mm.count() > 0
        b = mm[1] + "/live/" + mm[3] + "/" + mm[4] + "/" + mm[5]
        return { url: b + ".m3u8", fmt: "hls", alt: url, altFmt: "ts" }
    end if
    low = LCase(url)
    q = Instr(1, low, "?")
    if q > 0 then low = Left(low, q - 1)
    ext = ""
    for i = Len(low) to 1 step -1
        ch = Mid(low, i, 1)
        if ch = "." then
            ext = Mid(low, i + 1)
            exit for
        end if
        if ch = "/" then exit for
    end for
    if ext = "" then return { url: url, fmt: "hls", alt: url, altFmt: "ts" }
    if ext = "ts" then return { url: url, fmt: "ts", alt: url, altFmt: "hls" }
    return { url: url, fmt: fmtFor(ext), alt: "", altFmt: "" }
end function

function parseM3U(text as string, limit as integer) as object
    q = Chr(34)
    attrRx = CreateObject("roRegex", "([A-Za-z0-9_-]+)=" + q + "([^" + q + "]*)" + q, "")
    lines = text.Tokenize(Chr(10))
    out = {}
    for each mode in ["live", "movies", "series"]
        out[mode] = { cats: [], lists: [], index: {}, count: 0 }
    end for
    cur = invalid
    total = 0
    for each raw in lines
        l = raw.Trim()
        if l = ""
            ' skip
        else if Left(l, 7) = "#EXTINF"
            cur = { name: "Channel", group: "Uncategorized", logo: "" }
            lastQ = 0
            for i = Len(l) to 1 step -1
                if Mid(l, i, 1) = q then
                    lastQ = i
                    exit for
                end if
            end for
            c = Instr(lastQ + 1, l, ",")
            if c > 0 then cur.name = Mid(l, c + 1).Trim()
            for each mt in attrRx.MatchAll(l)
                key = LCase(mt[1])
                if key = "group-title" and mt[2] <> "" then cur.group = mt[2]
                if key = "tvg-logo" then cur.logo = mt[2]
            end for
        else if Left(l, 1) = "#"
            ' other directives ignored
        else if cur <> invalid
            total = total + 1
            if total > limit then exit for
            low = LCase(l)
            mode = "live"
            kind = "live"
            if Instr(1, low, "/movie/") > 0 or Right(low, 4) = ".mp4" or Right(low, 4) = ".mkv" then
                mode = "movies"
                kind = "movie"
            end if
            if Instr(1, low, "/series/") > 0 then
                mode = "series"
                kind = "episode"
            end if
            bucket = out[mode]
            idx = bucket.index[cur.group]
            if idx = invalid
                idx = bucket.lists.count()
                bucket.index[cur.group] = idx
                bucket.cats.push({ id: "m" + idx.ToStr(), name: cur.group })
                row = CreateObject("roSGNode", "ContentNode")
                row.title = cur.group
                bucket.lists.push(row)
            end if
            mu = m3uUrl(l)
            rec = { k: kind, i: "", t: cur.name, g: cur.logo, u: mu.url, f: mu.fmt, a: mu.alt, af: mu.altFmt, c: "m" + idx.ToStr() }
            recToNode(rec, invalid, "", bucket.lists[idx])
            bucket.count = bucket.count + 1
            cur = invalid
        end if
    end for
    res = {}
    for each mode in ["live", "movies", "series"]
        res[mode] = { cats: out[mode].cats, lists: out[mode].lists, count: out[mode].count }
    end for
    res.info = res.live.count.ToStr() + " channels - " + res.movies.count.ToStr() + " movies - " + res.series.count.ToStr() + " episodes"
    return res
end function
