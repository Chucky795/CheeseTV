' CheeseTV for Roku - main scene: navigation, Home rows, category grids, search, series, settings.
' MIT License, (c) 2026 CheeseTV (watchcheesetv.com).
' Ships EMPTY: the user adds their own M3U URL or Xtream Codes login; it is saved in the registry.

sub init()
    m.top.backgroundColor = "0x060A14FF"
    m.top.backgroundUri = ""
    ids = ["topBar", "tabTitle", "nav", "clock", "homeGroup", "heroTagBg", "heroTagText", "heroTitle", "heroLine1", "heroProgBg", "heroProg", "heroDesc", "heroBtn", "heroHint", "heroArt", "favTip", "rows", "gridGroup", "chips", "grid", "gridMsg", "gridMsgTitle", "gridMsgBody", "guideGroup", "gChips", "dayGrid", "gTitle", "gTime", "gBadge", "timeGrid", "guideMsg", "seriesGroup", "sPoster", "sTitle", "sMeta", "sPlot", "seasons", "episodes", "epDesc", "settingsGroup", "settingsMenu", "aboutVer", "aboutAcct", "welcomeGroup", "welcomeBtn", "plGroup", "plList", "plMsg", "plHint", "formGroup", "formTitle", "formList", "formWarn", "formMsg", "video", "osd", "chBadge", "osdSub", "osdLogo", "osdTitle", "osdStar", "osdCu", "osdNow", "osdProgBg", "osdProg", "osdHead", "osdShift", "ctrl", "osdNext", "osdHint", "osdClock", "pauseBadge", "chPanel", "chList", "pStatus", "toast", "toastText", "loading", "loadingText", "loadingSub", "retryTimer", "stallTimer", "epgTimer", "osdTimer", "toastTimer", "guideTimer", "chipTimer", "clockTimer"]
    for each id in ids
        m[id] = m.top.findNode(id)
    end for
    m.top.findNode("spinner").poster.uri = "pkg:/images/spinner.png"
    m.top.findNode("spinner").poster.width = 96
    m.top.findNode("spinner").poster.height = 96

    m.tabs = [["Home", "home"], ["Guide", "guide"], ["Live", "live"], ["Movies", "movies"], ["Series", "series"], ["Search", "search"], ["Settings", "settings"]]
    navc = CreateObject("roSGNode", "ContentNode")
    for each t in m.tabs
        c = navc.createChild("ContentNode")
        c.title = t[0]
        c.addFields({ sel: false, chip: false, tab: t[1] })
    end for
    m.nav.content = navc

    wb = CreateObject("roSGNode", "ContentNode")
    wbi = wb.createChild("ContentNode")
    wbi.title = "+  Add playlist / Xtream login"
    m.welcomeBtn.content = wb

    m.nav.observeField("itemSelected", "onNavSelected")
    m.rows.observeField("rowItemFocused", "onRowFocused")
    m.rows.observeField("rowItemSelected", "onRowSelected")
    m.chips.observeField("rowItemFocused", "onChipFocused")
    m.chips.observeField("rowItemSelected", "onChipSelected")
    m.grid.observeField("itemFocused", "onGridFocused")
    m.grid.observeField("itemSelected", "onGridSelected")
    m.seasons.observeField("itemFocused", "onSeasonFocused")
    m.episodes.observeField("itemFocused", "onEpisodeFocused")
    m.episodes.observeField("itemSelected", "onEpisodeSelected")
    m.settingsMenu.observeField("itemSelected", "onSettingSelected")
    m.welcomeBtn.observeField("itemSelected", "onWelcomeSelected")
    m.plList.observeField("itemSelected", "onPlSelected")
    m.formList.observeField("itemSelected", "onFormSelected")
    m.epgTimer.observeField("fire", "onEpgTimer")
    m.toastTimer.observeField("fire", "hideToast")
    m.chipTimer.observeField("fire", "onChipTimer")
    m.clockTimer.observeField("fire", "updateClock")
    m.clockTimer.control = "start"
    ' 2.0.2: registry writes go through a Task, debounced, so * never waits for Flush.
    m.regTask = CreateObject("roSGNode", "RegTask")
    m.regTask.observeField("result", "onRegResult")
    m.regTask.control = "RUN"
    m.regPending = {}
    m.regTimer = CreateObject("roSGNode", "Timer")
    m.regTimer.repeat = false
    m.regTimer.duration = 0.8
    m.regTimer.observeField("fire", "flushRegistry")
    initPlayer()
    initGuide()
    updateClock()

    m.state = ""
    m.screen = ""
    m.tab = "home"
    m.reqId = 0
    m.rowReqs = {}
    m.epgCache = {}
    m.epgCount = 0
    m.cats = { live: [], movies: [], series: [] }
    m.m3u = invalid
    m.acc = invalid
    m.connected = false
    m.launched = false
    m.dlg = invalid
    m.searchQ = ""
    m.searchRoot = invalid
    m.version = appVersion()
    loadState()
    p = activePlaylist()
    if p <> invalid
        connect(p)
    else if m.plists.count() > 0
        showPlaylists("")
    else
        showWelcome()
    end if
end sub

function appVersion() as string
    ai = CreateObject("roAppInfo")
    return ai.GetVersion()
end function

sub markLaunched()
    if m.launched then return
    m.launched = true
    m.top.signalBeacon("AppLaunchComplete")
end sub

' ---------------- generic helpers ----------------
sub updateClock()
    d = CreateObject("roDateTime")
    t = hhmm(d.AsSeconds())
    m.clock.text = t
    m.osdClock.text = t
end sub

sub setLoading(on as boolean, text = "Loading…" as string, sub_ = "" as string)
    m.loadingText.text = text
    m.loadingSub.text = sub_
    m.loading.visible = on
end sub

sub showToast(text as string)
    m.toastText.text = text
    m.toast.visible = true
    m.toastTimer.control = "stop"
    m.toastTimer.control = "start"
end sub

sub hideToast()
    m.toast.visible = false
end sub

function isX() as boolean
    return m.acc <> invalid and m.acc.type = "xtream"
end function

function fmtPref() as string
    f = m.settings.fmt
    if f = invalid then return "auto"
    return f
end function

function api(kind as string, extra as object, callback as string) as integer
    m.reqId = m.reqId + 1
    t = CreateObject("roSGNode", "ApiTask")
    r = { id: m.reqId, kind: kind, account: m.acc, pref: fmtPref() }
    if m.favSet <> invalid then r.favKeys = m.favSet
    r.Append(extra)
    t.request = r
    t.observeField("response", callback)
    t.control = "RUN"
    return m.reqId
end function

sub hideAll()
    for each g in ["topBar", "homeGroup", "gridGroup", "guideGroup", "seriesGroup", "settingsGroup", "welcomeGroup", "plGroup", "formGroup"]
        m[g].visible = false
    end for
end sub

' ---------------- dialogs ----------------
sub showChoice(kind as string, title as string, lines as object, buttons as object)
    closeDialog()
    m.focusBeforeDlg = focusedNode()
    dlg = CreateObject("roSGNode", "StandardMessageDialog")
    dlg.title = title
    dlg.message = lines
    dlg.buttons = buttons
    dlg.observeField("buttonSelected", "onDlgButton")
    dlg.observeField("wasClosed", "onDlgClosed")
    m.dlg = dlg
    m.dlgKind = kind
    m.dlgText = false
    m.top.dialog = dlg
end sub

sub askText(kind as string, title as string, msg as string, text as string, domain as string)
    closeDialog()
    m.focusBeforeDlg = focusedNode()
    dlg = CreateObject("roSGNode", "StandardKeyboardDialog")
    dlg.title = title
    if msg <> "" then dlg.message = [msg]
    dlg.buttons = ["OK", "Cancel"]
    dlg.keyboardDomain = domain
    dlg.text = text
    teb = dlg.textEditBox
    if teb <> invalid then teb.cursorPosition = Len(text)
    dlg.observeField("buttonSelected", "onDlgButton")
    dlg.observeField("wasClosed", "onDlgClosed")
    m.dlg = dlg
    m.dlgKind = kind
    m.dlgText = true
    m.top.dialog = dlg
end sub

sub closeDialog()
    if m.dlg <> invalid
        m.dlg.unobserveField("buttonSelected")
        m.dlg.unobserveField("wasClosed")
        m.dlg.close = true
        m.dlg = invalid
    end if
    m.top.dialog = invalid
end sub

sub onDlgButton()
    dlg = m.dlg
    if dlg = invalid then return
    idx = dlg.buttonSelected
    kind = m.dlgKind
    txt = ""
    if m.dlgText then txt = dlg.text.Trim()
    isText = m.dlgText
    closeDialog()
    restoreFocus()
    if isText
        if idx = 0 then onTextEntered(kind, txt)
    else
        onChoice(kind, idx)
    end if
end sub

sub onDlgClosed()
    kind = m.dlgKind
    m.dlg = invalid
    m.top.dialog = invalid
    restoreFocus()
    onChoice(kind, -1)
end sub

function focusedNode() as dynamic
    for each n in [m.nav, m.rows, m.chips, m.grid, m.timeGrid, m.gChips, m.dayGrid, m.seasons, m.episodes, m.settingsMenu, m.welcomeBtn, m.plList, m.formList, m.video, m.ctrl, m.chList]
        if n.hasFocus() then return n
    end for
    return invalid
end function

sub restoreFocus()
    if m.focusBeforeDlg <> invalid then m.focusBeforeDlg.setFocus(true)
end sub

sub onChoice(kind as string, idx as integer)
    if kind = "exit"
        if idx = 0
            flushRegistrySync()
            m.top.exitApp = true
        end if
    else if kind = "resume"
        playerResumeChoice(idx)
    else if kind = "plOptions"
        plOptionsChoice(idx)
    else if kind = "plDelete"
        plDeleteChoice(idx)
    else if kind = "addFailed"
        addFailedChoice(idx)
    else if kind = "clearFavs"
        if idx = 0
            m.favs = []
            saveFavs()
            showToast("Favorites cleared")
            showSettings()
        end if
    else if kind = "future"
        if idx = 0 then guideWatchFocused()
    end if
end sub

sub onTextEntered(kind as string, txt as string)
    if kind = "search"
        runSearch(txt)
    else if Left(kind, 5) = "form:"
        formFieldEntered(Mid(kind, 6), txt)
    end if
end sub

sub askExit()
    showChoice("exit", "Exit CheeseTV?", ["Do you want to close CheeseTV?"], ["Exit", "Cancel"])
end sub

' ---------------- main / navigation ----------------
sub enterMain()
    setLoading(false)
    m.connected = true
    m.screen = "main"
    loadFavs()
    loadRecents()
    showTab("home", true)
    markLaunched()
end sub

sub showTab(tabId as string, wantContent as boolean)
    m.tab = tabId
    m.screen = "main"
    hideAll()
    m.topBar.visible = true
    idx = 0
    navc = m.nav.content
    for i = 0 to navc.getChildCount() - 1
        c = navc.getChild(i)
        c.sel = (c.tab = tabId)
        if c.sel then
            idx = i
            m.tabTitle.text = c.title
        end if
    end for
    m.nav.jumpToItem = idx
    if tabId = "home"
        buildHome()
    else if tabId = "live" or tabId = "movies" or tabId = "series"
        showGrid(tabId)
    else if tabId = "search"
        showSearch()
    else if tabId = "guide"
        showGuide()
    else if tabId = "settings"
        showSettings()
    end if
    if wantContent then focusContent() else m.nav.setFocus(true)
end sub

sub focusContent()
    t = m.tab
    if t = "home"
        m.rows.setFocus(true)
    else if t = "live" or t = "movies" or t = "series" or t = "search"
        if m.grid.content <> invalid and m.grid.content.getChildCount() > 0 and t <> "search" then m.grid.setFocus(true) else m.chips.setFocus(true)
    else if t = "guide"
        guideFocus()
    else if t = "settings"
        m.settingsMenu.setFocus(true)
    end if
end sub

'  The OK press that picked a tab must not also open the first tile it moved focus to.
function justNavigated() as boolean
    if m.navSelAt = invalid then return false
    t = m.navSelAt.TotalMilliseconds()
    m.navSelAt = invalid
    return t < 250
end function

sub onNavSelected()
    m.navSelAt = CreateObject("roTimespan")
    c = m.nav.content.getChild(m.nav.itemSelected)
    if c <> invalid then showTab(c.tab, true)
end sub

' ---------------- storage: favorites + continue watching ----------------
' 2.0.2: Roku allows 16 KB of registry per channel IN TOTAL. Favorites / Continue Watching are
' compact records (kind, id, short title, short logo URL) kept inside a byte budget that is
' shared by all playlists, and they are written by RegTask, never on the render thread.
function favBudget() as integer
    n = 1
    if m.plists <> invalid and m.plists.count() > 1 then n = m.plists.count()
    b = Int(8000 / n)
    if b < 800 then b = 800
    return b
end function

function recBudget() as integer
    b = Int(favBudget() / 3)
    if b < 400 then b = 400
    return b
end function

function compactList(list as dynamic, cap as integer) as object
    out = []
    if type(list) <> "roArray" then return out
    for each r in list
        if type(r) = "roAssociativeArray"
            c = { k: r.k, i: r.i, t: Left(toStr(r.t), 48) }
            if r.g <> invalid and Len(toStr(r.g)) <= 160 then c.g = r.g
            if r.x <> invalid and Len(toStr(r.x)) <= 5 then c.x = r.x
            if r.ar <> invalid and toInt(r.ar) > 0 then c.ar = r.ar
            if r.e <> invalid and Len(toStr(r.e)) <= 24 then c.e = r.e
            if r.p <> invalid and toInt(r.p) > 0 then c.p = r.p
            if toStr(r.i) = ""
                if r.u <> invalid then c.u = r.u
                if r.f <> invalid then c.f = r.f
                if r.a <> invalid and Len(toStr(r.a)) <= 300 then c.a = r.a : c.af = r.af
            end if
            out.push(c)
            if out.count() >= cap then exit for
        end if
    end for
    return out
end function

sub loadFavs()
    raw = regRead("fav_" + m.acc.id, [])
    m.favs = fitRecs(compactList(raw, 40), favBudget())
    rebuildFavSet()
    ' migrate 2.0.1's bigger records (in the background)
    if type(raw) <> "roArray" or Len(FormatJson(m.favs)) < Len(FormatJson(raw)) then saveFavs()
end sub

sub rebuildFavSet()
    m.favSet = {}
    for each r in m.favs
        m.favSet[recKey(r)] = true
    end for
end sub

sub saveFavs()
    rebuildFavSet()
    m.favs = fitRecs(m.favs, favBudget())
    regWriteAsync("fav_" + m.acc.id, m.favs)
end sub

sub loadRecents()
    raw = regRead("rec_" + m.acc.id, [])
    m.recents = fitRecs(compactList(raw, 20), recBudget())
    if type(raw) <> "roArray" or Len(FormatJson(m.recents)) < Len(FormatJson(raw)) then saveRecents()
end sub

sub saveRecents()
    m.recents = fitRecs(m.recents, recBudget())
    regWriteAsync("rec_" + m.acc.id, m.recents)
end sub

sub regWriteAsync(key as string, value as dynamic)
    m.regPending[key] = value
    m.regTimer.control = "stop"
    m.regTimer.control = "start"
end sub

sub flushRegistry()
    for each key in m.regPending
        m.regTask.job = { key: key, value: FormatJson(m.regPending[key]) }
    end for
    m.regPending = {}
end sub

' Used right before exiting: write anything still waiting for the debounce timer.
sub flushRegistrySync()
    if m.regPending.count() = 0 then return
    m.regTimer.control = "stop"
    sec = regSec()
    for each key in m.regPending
        sec.Write(key, FormatJson(m.regPending[key]))
    end for
    sec.Flush()
    m.regPending = {}
end sub

sub onRegResult()
    r = m.regTask.result
    if type(r) = "roAssociativeArray" and r.ok = false then showToast("Couldn't save Favorites (TV storage is full)")
end sub

function canFav(it as dynamic) as boolean
    if it = invalid then return false
    k = it.kind
    return k = "live" or k = "movie" or k = "series" or k = "episode"
end function

sub toggleFav(it as dynamic)
    if not canFav(it) then return
    key = nodeKey(it)
    if m.favSet.DoesExist(key)
        out = []
        for each r in m.favs
            if recKey(r) <> key then out.push(r)
        end for
        m.favs = out
        it.fav = false
        saveFavs()
        updateFavRow(it, key, false)
        showToast("Removed from Favorites")
    else
        m.favs.Unshift(compactRec(it, isX()))
        while m.favs.count() > 40
            m.favs.Pop()
        end while
        it.fav = true
        saveFavs()
        updateFavRow(it, key, true)
        showToast("★ Added to Favorites")
    end if
end sub

' 2.0.2: only the Favorites row on Home changes (one tile added / its star cleared); Home is not
' rebuilt. Removed tiles disappear the next time Home is opened, so focus never jumps.
sub updateFavRow(it as object, key as string, added as boolean)
    root = m.rows.content
    if root = invalid then return
    ' same item in other Home rows (Continue Watching, etc.): flip their star too (small rows only)
    nr = root.getChildCount()
    if nr > 12 then nr = 12
    for r = 0 to nr - 1
        row = root.getChild(r)
        n = row.getChildCount()
        if n > 60 then n = 60
        for i = 0 to n - 1
            c = row.getChild(i)
            if c <> invalid and c.hasField("fav") and nodeKey(c) = key then c.fav = added
        end for
    end for
    row = root.getChild(0)
    if added and row <> invalid and row.title = "★ Favorites" and row.getChildCount() < 40
        node = recToNode(compactRec(it, isX()), m.acc, fmtPref(), invalid)
        node.fav = true
        row.insertChild(node, 0)
    end if
end sub

sub markFavs(list as dynamic)
    if list = invalid then return
    n = list.getChildCount()
    ' 2.0.2: big lists are marked by ApiTask (favKeys); here only small ones (rows, search).
    if n > 300 then n = 300
    for i = 0 to n - 1
        c = list.getChild(i)
        if c.hasField("fav") then c.fav = m.favSet.DoesExist(nodeKey(c))
    end for
end sub

sub addRecent(it as object)
    if not canFav(it) or it.kind = "series" then return
    key = nodeKey(it)
    out = [compactRec(it, isX())]
    for each r in m.recents
        if recKey(r) <> key then out.push(r)
        if out.count() >= 20 then exit for
    end for
    m.recents = out
    saveRecents()
end sub

sub setRecentPos(it as object, posSecs as integer)
    key = nodeKey(it)
    for each r in m.recents
        if recKey(r) = key
            if toInt(r.p) = posSecs then return
            r.p = posSecs
            saveRecents()
            return
        end if
    end for
end sub

function recentPos(it as object) as integer
    key = nodeKey(it)
    for each r in m.recents
        if recKey(r) = key then return toInt(r.p)
    end for
    return 0
end function

' ---------------- rows / tiles helpers ----------------
function tileNode(parent as object, kind as string, title as string) as object
    c = parent.createChild("ContentNode")
    c.title = title
    c.addFields({ kind: kind, act: "" })
    return c
end function

function styleOf(mode as string) as string
    if mode = "live" then return "live"
    return "poster"
end function

sub addRecRow(root as object, title as string, recs as object, style as string)
    row = root.createChild("ContentNode")
    row.title = title
    row.addFields({ mode: "", catId: "", st: "loaded", style: style })
    for each r in recs
        it = recToNode(r, m.acc, fmtPref(), row)
        it.fav = m.favSet.DoesExist(recKey(r))
    end for
end sub

sub addLazyRow(root as object, title as string, mode as string, catId as string)
    row = root.createChild("ContentNode")
    row.title = title
    row.addFields({ mode: mode, catId: catId, st: "idle", style: styleOf(mode) })
    tileNode(row, "loading", "Loading…")
end sub

' ---------------- Home ----------------
sub buildHome()
    m.homeGroup.visible = true
    root = CreateObject("roSGNode", "ContentNode")
    if m.favs.count() > 0 then addRecRow(root, "★ Favorites", m.favs, "live")
    if m.recents.count() > 0 then addRecRow(root, "Continue Watching", m.recents, "live")
    n = 0
    for each c in m.cats.live
        addLazyRow(root, c.name, "live", c.id)
        n = n + 1
        if n >= 8 then exit for
    end for
    if m.cats.movies.count() > 0 then addLazyRow(root, "Movies", "movies", m.cats.movies[0].id)
    if m.cats.series.count() > 0 then addLazyRow(root, "Series", "series", m.cats.series[0].id)
    if root.getChildCount() = 0
        row = root.createChild("ContentNode")
        row.title = "No channels yet"
        row.addFields({ mode: "", catId: "", st: "loaded", style: "live" })
        tileNode(row, "hint", "Your playlist has no channels yet.")
    end if
    m.favTip.visible = m.favs.count() = 0
    if m.favTip.visible then m.rows.translation = [56, 556] else m.rows.translation = [56, 520]
    sizes = []
    heights = []
    for i = 0 to root.getChildCount() - 1
        r = root.getChild(i)
        if r.style = "live"
            sizes.push([300, 210])
            heights.push(290)
        else
            sizes.push([200, 330])
            heights.push(410)
        end if
    end for
    m.rows.setFields({ rowItemSize: sizes, rowHeights: heights, rowItemSpacing: [[24, 0]], showRowLabel: [true], rowLabelOffset: [[0, 12]], numRows: 2, itemSize: [1864, 290] })
    m.rows.content = root
    m.homeRoot = root
    m.rows.jumpToRowItem = [0, 0]
    ensureRows(0)
    first = root.getChild(0).getChild(0)
    updateHero(first, root.getChild(0))
end sub

sub ensureRows(r as integer)
    root = m.rows.content
    if root = invalid then return
    for i = r - 1 to r + 2
        row = root.getChild(i)
        if row <> invalid and row.st = "idle" then loadRow(root, i)
    end for
end sub

sub loadRow(root as object, idx as integer)
    row = root.getChild(idx)
    row.st = "loading"
    if m.m3u <> invalid
        src = m3uList(row.mode, row.catId)
        fillRow(row, invalidOrClone(src, 40))
        return
    end if
    id = api("items", { mode: row.mode, catId: row.catId, limit: 40 }, "onRowItems")
    m.rowReqs[id.ToStr()] = { root: root, idx: idx }
end sub

function invalidOrClone(src as dynamic, cap as integer) as object
    out = CreateObject("roSGNode", "ContentNode")
    if src = invalid then return out
    n = src.getChildCount()
    if n > cap then n = cap
    for i = 0 to n - 1
        recToNode(nodeToRec(src.getChild(i), false), invalid, fmtPref(), out)
    end for
    return out
end function

sub onRowItems(ev as object)
    res = ev.getData()
    key = res.id.ToStr()
    info = m.rowReqs[key]
    if info = invalid then return
    m.rowReqs.Delete(key)
    if m.rows.content = invalid or not info.root.isSameNode(m.rows.content) then return
    row = info.root.getChild(info.idx)
    if row = invalid then return
    fillRow(row, res.data)
end sub

sub fillRow(row as object, data as object)
    row.removeChildrenIndex(row.getChildCount(), 0)
    kids = data.getChildren(-1, 0)
    if kids.count() = 0
        tileNode(row, "hint", "Nothing here yet")
    else
        row.appendChildren(kids)
        markFavs(row)
    end if
    row.st = "loaded"
    rf = m.rows.rowItemFocused
    if rf <> invalid and rf.count() = 2 and m.rows.content <> invalid
        fr = m.rows.content.getChild(rf[0])
        if fr <> invalid and fr.isSameNode(row)
            updateHero(row.getChild(rf[1]), row)
            scheduleEpg(row, rf[1])
        end if
    end if
end sub

function m3uList(mode as string, catId as string) as dynamic
    if m.m3u = invalid then return invalid
    b = m.m3u[mode]
    if b = invalid then return invalid
    i = 0
    for each c in b.cats
        if c.id = catId then return b.lists[i]
        i = i + 1
    end for
    return invalid
end function

sub onRowFocused()
    rf = m.rows.rowItemFocused
    if rf = invalid or rf.count() < 2 or m.rows.content = invalid then return
    row = m.rows.content.getChild(rf[0])
    if row = invalid then return
    updateHero(row.getChild(rf[1]), row)
    ensureRows(rf[0])
    scheduleEpg(row, rf[1])
end sub

sub onRowSelected()
    if justNavigated() then return
    rs = m.rows.rowItemSelected
    row = m.rows.content.getChild(rs[0])
    if row = invalid then return
    openItem(row.getChild(rs[1]), row)
end sub

sub openItem(it as dynamic, list as object)
    if it = invalid then return
    k = it.kind
    if k = "live" or k = "movie" or k = "episode"
        playItem(it, list)
    else if k = "series"
        openSeries(it)
    else if k = "action"
        if it.act = "search" then askSearch()
    end if
end sub

sub updateHero(it as dynamic, row as dynamic)
    m.heroItem = it
    k = ""
    if it <> invalid then k = it.kind
    m.heroProg.visible = false
    m.heroProgBg.visible = false
    m.heroDesc.text = ""
    m.heroLine1.text = ""
    if k = "live" or k = "movie" or k = "series" or k = "episode"
        live = (k = "live")
        if live
            m.heroTagBg.blendColor = "0xE53935FF"
            m.heroTagText.text = "LIVE"
            m.heroTagText.color = "0xFFFFFFFF"
        else
            m.heroTagBg.blendColor = "0xF5C242FF"
            m.heroTagText.text = "FEATURED"
            m.heroTagText.color = "0x1A1300FF"
        end if
        m.heroTitle.text = it.title
        sub_ = ""
        if row <> invalid and row.title <> invalid then sub_ = row.title
        if live
            e = epgNowNext(it.sid)
            if e <> invalid and e.now <> invalid
                m.heroLine1.text = "Now: " + e.now.t
                setProgress(m.heroProg, m.heroProgBg, e.now, 420)
            else
                m.heroLine1.text = sub_
            end if
            if it.archive > 0 then m.heroLine1.text = m.heroLine1.text + "   ↺ Catch-up " + it.archive.ToStr() + " days"
        else
            m.heroLine1.text = sub_
            if it.description <> "" then m.heroDesc.text = it.description
            if m.heroDesc.text <> "" then m.heroDesc.translation = [56, 212]
        end if
        hint = "OK Watch   ·   * Favorite"
        if k = "series" then hint = "OK Episodes   ·   * Favorite"
        m.heroHint.text = hint
        m.heroBtn.visible = true
        uri = it.HDPosterUrl
        if uri = "" then uri = "pkg:/images/logo.png"
        m.heroArt.uri = uri
    else
        m.heroTagBg.blendColor = "0xF5C242FF"
        m.heroTagText.text = "FEATURED"
        m.heroTagText.color = "0x1A1300FF"
        m.heroTitle.text = "CheeseTV"
        m.heroLine1.text = "Live TV, movies and series from your own playlist"
        m.heroHint.text = ""
        m.heroBtn.visible = false
        m.heroArt.uri = "pkg:/images/logo.png"
    end if
end sub

sub setProgress(bar as object, bg as object, prog as object, width as integer)
    now = nowSecs()
    if prog.e <= prog.s then return
    f = (now - prog.s) / (prog.e - prog.s)
    if f < 0 then f = 0
    if f > 1 then f = 1
    bg.visible = true
    bar.visible = true
    bg.width = width
    bar.width = Int(width * f)
end sub

' ---------------- EPG (now / next) ----------------
function epgNowNext(sid as dynamic) as dynamic
    if sid = invalid or sid = "" then return invalid
    lst = m.epgCache[sid]
    if lst = invalid then return invalid
    now = nowSecs()
    res = { now: invalid, next: invalid }
    for each e in lst
        if e.s <= now and e.e > now
            res.now = e
        else if e.s > now and res.next = invalid
            res.next = e
        end if
    end for
    if res.now = invalid and res.next = invalid then return invalid
    return res
end function

function epgFresh(sid as string) as boolean
    if not m.epgCache.DoesExist(sid) then return false
    lst = m.epgCache[sid]
    if lst.count() = 0 then return true
    return lst[lst.count() - 1].e > nowSecs()
end function

sub scheduleEpg(list as dynamic, col as integer)
    if not isX() or list = invalid then return
    m.epgList = list
    m.epgCol = col
    m.epgTimer.control = "stop"
    m.epgTimer.control = "start"
end sub

sub onEpgTimer()
    list = m.epgList
    if list = invalid then return
    sids = []
    for i = m.epgCol - 1 to m.epgCol + 6
        c = list.getChild(i)
        if c <> invalid and c.kind = "live" and c.sid <> ""
            if not epgFresh(c.sid) then sids.push(c.sid)
        end if
    end for
    applyEpg(list)
    if sids.count() = 0 then return
    api("epgBatch", { sids: sids }, "onEpgBatch")
end sub

sub onEpgBatch(ev as object)
    res = ev.getData()
    if res.data = invalid then return
    if m.epgCount > 500
        m.epgCache = {}
        m.epgCount = 0
    end if
    for each sid in res.data.map
        m.epgCache[sid] = res.data.map[sid]
        m.epgCount = m.epgCount + 1
    end for
    if m.epgList <> invalid then applyEpg(m.epgList)
    if m.heroItem <> invalid and m.screen = "main" and m.tab = "home"
        rf = m.rows.rowItemFocused
        row = invalid
        if rf <> invalid and rf.count() = 2 and m.rows.content <> invalid then row = m.rows.content.getChild(rf[0])
        updateHero(m.heroItem, row)
    end if
    if m.screen = "player" then refreshOsdEpg()
end sub

sub applyEpg(list as object)
    for i = m.epgCol - 1 to m.epgCol + 6
        c = list.getChild(i)
        if c <> invalid and c.kind = "live"
            e = epgNowNext(c.sid)
            if e <> invalid and e.now <> invalid then c.epg = e.now.t
        end if
    end for
end sub

' ---------------- Live / Movies / Series grids ----------------
sub showGrid(mode as string)
    m.gridGroup.visible = true
    m.gridMode = mode
    chips = CreateObject("roSGNode", "ContentNode")
    row = chips.createChild("ContentNode")
    f = row.createChild("ContentNode")
    f.title = "★ Favorites"
    f.addFields({ chip: true, sel: false, catId: "*fav" })
    for each c in m.cats[mode]
        ch = row.createChild("ContentNode")
        ch.title = c.name
        ch.addFields({ chip: true, sel: false, catId: c.id })
    end for
    m.chips.content = chips
    setGridLayout(mode)
    start = 1
    if row.getChildCount() = 1 then start = 0
    m.chips.jumpToRowItem = [0, start]
    selectChip(start)
end sub

sub setGridLayout(mode as string)
    if mode = "live"
        m.grid.setFields({ numColumns: 5, numRows: 3, itemSize: [340, 236], itemSpacing: [22, 28] })
    else
        m.grid.setFields({ numColumns: 8, numRows: 2, itemSize: [204, 360], itemSpacing: [18, 34] })
    end if
end sub

sub onChipFocused()
    if m.tab = "search" then return
    m.chipTimer.control = "stop"
    m.chipTimer.control = "start"
end sub

sub onChipTimer()
    rf = m.chips.rowItemFocused
    if rf = invalid or rf.count() < 2 then return
    if rf[1] <> m.chipSel then selectChip(rf[1])
end sub

sub onChipSelected()
    rs = m.chips.rowItemSelected
    if m.tab = "search"
        searchChip(rs[1])
        return
    end if
    if rs[1] <> m.chipSel then selectChip(rs[1])
    if m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then m.grid.setFocus(true)
end sub

sub setChipSel(i as integer)
    row = m.chips.content.getChild(0)
    for j = 0 to row.getChildCount() - 1
        row.getChild(j).sel = (j = i)
    end for
    m.chipSel = i
end sub

function kindForMode(mode as string) as string
    if mode = "live" then return "live"
    if mode = "movies" then return "movie"
    return "series"
end function

function titleForMode(mode as string) as string
    if mode = "live" then return "Live TV"
    if mode = "movies" then return "Movies"
    return "Series"
end function

sub selectChip(i as integer)
    setChipSel(i)
    chip = m.chips.content.getChild(0).getChild(i)
    if chip = invalid then return
    mode = m.gridMode
    if chip.catId = "*fav"
        list = CreateObject("roSGNode", "ContentNode")
        want = kindForMode(mode)
        for each r in m.favs
            if r.k = want or (want = "movie" and r.k = "episode")
                it = recToNode(r, m.acc, fmtPref(), list)
                it.fav = true
            end if
        end for
        setGridContent(list, "No favorites yet", "Press * on any channel, or in the player, to add it here.")
    else if m.m3u <> invalid
        lst = m3uList(mode, chip.catId)
        if lst <> invalid then markFavs(lst)
        setGridContent(lst, "No " + titleForMode(mode) + " found", "The list is empty.")
    else
        setGridMsg("Loading…", "Hang tight, your list is downloading.")
        m.grid.content = CreateObject("roSGNode", "ContentNode")
        m.gridReq = api("items", { mode: mode, catId: chip.catId, limit: 5000 }, "onGridItems")
    end if
end sub

sub onGridItems(ev as object)
    res = ev.getData()
    if res.id <> m.gridReq or m.screen <> "main" then return
    ' stars were set by ApiTask (favKeys) - no 5,000-item loop on the render thread
    if res.ok
        setGridContent(res.data, "No " + titleForMode(m.gridMode) + " found", "The list is empty.")
    else
        setGridContent(res.data, "Couldn't load this category", res.error + " Press OK on the category to try again.")
    end if
end sub

sub setGridContent(list as dynamic, emptyTitle as string, emptyBody as string)
    if list = invalid then list = CreateObject("roSGNode", "ContentNode")
    m.grid.content = list
    if list.getChildCount() = 0
        setGridMsg(emptyTitle, emptyBody)
        if m.grid.hasFocus() then m.chips.setFocus(true)
    else
        m.gridMsg.visible = false
        m.grid.jumpToItem = 0
        scheduleEpg(list, 0)
    end if
end sub

sub setGridMsg(title as string, body as string)
    m.gridMsgTitle.text = title
    m.gridMsgBody.text = body
    m.gridMsg.visible = true
end sub

sub onGridFocused()
    if m.grid.content = invalid then return
    scheduleEpg(m.grid.content, m.grid.itemFocused)
end sub

sub onGridSelected()
    if justNavigated() then return
    if m.grid.content = invalid then return
    openItem(m.grid.content.getChild(m.grid.itemSelected), m.grid.content)
end sub

function gridFocusedItem() as dynamic
    if m.grid.content = invalid then return invalid
    return m.grid.content.getChild(m.grid.itemFocused)
end function

' ---------------- Search ----------------
sub showSearch()
    m.gridGroup.visible = true
    chips = CreateObject("roSGNode", "ContentNode")
    row = chips.createChild("ContentNode")
    s = row.createChild("ContentNode")
    s.title = "Search"
    s.addFields({ chip: true, sel: false, catId: "*search" })
    if m.searchRoot <> invalid
        for i = 0 to m.searchRoot.getChildCount() - 1
            r = m.searchRoot.getChild(i)
            ch = row.createChild("ContentNode")
            ch.title = r.title + " (" + r.getChildCount().ToStr() + ")"
            ch.addFields({ chip: true, sel: false, catId: i.ToStr() })
        end for
    end if
    m.chips.content = chips
    m.grid.content = CreateObject("roSGNode", "ContentNode")
    if m.searchRoot <> invalid and m.searchRoot.getChildCount() > 0
        m.chips.jumpToRowItem = [0, 1]
        searchChip(1)
    else if m.searchQ <> ""
        setChipSel(0)
        setGridMsg("No results for " + Chr(34) + m.searchQ + Chr(34), "Try another name.")
    else
        setChipSel(0)
        setGridMsg("Search", "Press OK on Search and type a channel, movie or series name.")
    end if
end sub

sub searchChip(i as integer)
    if i = 0
        askSearch()
        return
    end if
    setChipSel(i)
    r = m.searchRoot.getChild(i - 1)
    if r = invalid then return
    setGridLayout(r.mode)
    m.gridMode = r.mode
    markFavs(r)
    setGridContent(r, "No results", "")
    m.grid.setFocus(true)
end sub

sub askSearch()
    askText("search", "Search", "Channels, movies and series", m.searchQ, "generic")
end sub

sub runSearch(q as string)
    m.searchQ = q
    if q = "" then return
    if m.m3u <> invalid
        m.searchRoot = m3uSearch(q, 60)
        showTab("search", true)
        return
    end if
    setLoading(true, "Searching…", "Big Xtream accounts can take a little while.")
    m.searchReq = api("search", { q: q }, "onSearch")
end sub

sub onSearch(ev as object)
    res = ev.getData()
    if res.id <> m.searchReq then return
    setLoading(false)
    m.searchRoot = res.data
    if m.screen = "main" and m.tab = "search" then showTab("search", true)
end sub

function m3uSearch(q as string, cap as integer) as object
    root = CreateObject("roSGNode", "ContentNode")
    ql = LCase(q)
    labels = { live: "Channels", movies: "Movies", series: "Series" }
    for each mode in ["live", "movies", "series"]
        row = CreateObject("roSGNode", "ContentNode")
        row.title = labels[mode]
        row.addFields({ mode: mode })
        budget = 8000
        for each lst in m.m3u[mode].lists
            n = lst.getChildCount()
            ' 2.0.2: bounded scan so a huge M3U can't stall the remote for seconds
            if n > budget then n = budget
            budget = budget - n
            for i = 0 to n - 1
                it = lst.getChild(i)
                if Instr(1, LCase(it.title), ql) > 0
                    recToNode(nodeToRec(it, false), invalid, fmtPref(), row)
                    if row.getChildCount() >= cap then exit for
                end if
            end for
            if row.getChildCount() >= cap then exit for
        end for
        if row.getChildCount() > 0 then root.appendChild(row)
    end for
    return root
end function

' ---------------- Series detail ----------------
sub openSeries(it as object)
    m.seriesItem = it
    m.seriesReturn = focusedNode()
    setLoading(true, "Loading…")
    m.seriesReq = api("series", { seriesId: it.sid }, "onSeries")
end sub

sub onSeries(ev as object)
    res = ev.getData()
    if res.id <> m.seriesReq then return
    setLoading(false)
    if not res.ok
        showToast(res.error)
        return
    end if
    d = res.data
    it = m.seriesItem
    hideAll()
    m.screen = "series"
    m.seriesGroup.visible = true
    title = d.info.name
    if title = "" then title = it.title
    m.sTitle.text = title
    meta = []
    if d.info.year <> "" then meta.push(d.info.year)
    if d.info.genre <> "" then meta.push(d.info.genre)
    if d.info.rating <> "" and d.info.rating <> "0" then meta.push("★ " + d.info.rating)
    m.sMeta.text = meta.Join("   ·   ")
    m.sPlot.text = d.info.plot
    poster = d.info.cover
    if poster = "" then poster = it.HDPosterUrl
    m.sPoster.uri = poster
    m.seasonsRoot = d.seasons
    m.seasons.content = d.seasons
    if d.seasons.getChildCount() = 0
        m.episodes.content = CreateObject("roSGNode", "ContentNode")
        m.epDesc.text = "No episodes found"
        m.seasons.setFocus(true)
        return
    end if
    m.seasons.jumpToItem = 0
    m.episodes.content = d.seasons.getChild(0)
    m.seasons.setFocus(true)
end sub

sub onSeasonFocused()
    if m.seasonsRoot = invalid then return
    s = m.seasonsRoot.getChild(m.seasons.itemFocused)
    if s <> invalid then m.episodes.content = s
end sub

sub onEpisodeFocused()
    c = m.episodes.content
    if c = invalid then return
    e = c.getChild(m.episodes.itemFocused)
    if e = invalid then return
    t = e.description
    if e.extra <> "" then t = e.extra + "   " + t
    m.epDesc.text = t
end sub

sub onEpisodeSelected()
    c = m.episodes.content
    if c = invalid then return
    e = c.getChild(m.episodes.itemSelected)
    if e <> invalid then playItem(e, c)
end sub

sub closeSeries()
    m.screen = "main"
    showTab(m.tab, true)
end sub

' ---------------- Settings ----------------
function fmtLabel() as string
    f = fmtPref()
    if f = "ts" then return "TS"
    if f = "hls" then return "HLS"
    return "Auto"
end function

sub showSettings()
    m.settingsGroup.visible = true
    m.aboutVer.text = "Version " + m.version + " - Roku"
    acct = ""
    if m.acc <> invalid
        acct = "Playlist: " + m.acc.name + Chr(10)
        if isX() then acct = acct + "Xtream - " + xBase(m.acc) + Chr(10) else acct = acct + "M3U" + Chr(10)
        if m.acctInfo <> invalid then acct = acct + m.acctInfo
    end if
    m.aboutAcct.text = acct
    items = [
        { t: "Playlist management", d: m.plists.count().ToStr() + " playlist(s)  -  add, edit or delete", a: "1", id: "playlists" }
        { t: "Live stream format (Xtream)", d: fmtLabel() + "  -  OK to change (Auto / TS / HLS)", a: "", id: "fmt" }
        { t: "Continue Watching", d: "Clear the Continue Watching row (" + m.recents.count().ToStr() + ").", a: "", id: "clearRecent" }
        { t: "Favorites", d: m.favs.count().ToStr() + " saved  -  OK to remove all", a: "", id: "clearFavs" }
        { t: "Visit watchcheesetv.com", d: "Scan the QR code with your phone", a: "", id: "site" }
        { t: "Support", d: "cheesetv795@gmail.com", a: "", id: "support" }
        { t: "App version", d: m.version + " (Roku)", a: "", id: "version" }
        { t: "License & credits", d: "MIT license  -  Inter font (SIL OFL 1.1)", a: "", id: "license" }
    ]
    root = CreateObject("roSGNode", "ContentNode")
    for each i in items
        c = root.createChild("ContentNode")
        c.title = i.t
        c.description = i.d
        c.addFields({ arrow: i.a, sid: i.id, icon: "", section: "", tone: "" })
    end for
    keep = m.settingsMenu.itemFocused
    m.settingsMenu.content = root
    if keep > 0 then m.settingsMenu.jumpToItem = keep
end sub

sub onSettingSelected()
    c = m.settingsMenu.content.getChild(m.settingsMenu.itemSelected)
    id = c.sid
    if id = "playlists"
        showPlaylists("")
    else if id = "fmt"
        f = fmtPref()
        if f = "auto" then f = "ts" else if f = "ts" then f = "hls" else f = "auto"
        m.settings.fmt = f
        regWrite("settings", m.settings)
        showSettings()
        showToast("Live stream format: " + fmtLabel() + " - applies to the next channel you open")
    else if id = "clearRecent"
        m.recents = []
        saveRecents()
        showSettings()
        showToast("Continue Watching cleared")
    else if id = "clearFavs"
        showChoice("clearFavs", "Remove all favorites?", ["This removes every favorite for this playlist."], ["Remove all", "Cancel"])
    else if id = "site"
        showToast("Scan the QR code with your phone camera to open watchcheesetv.com")
    else if id = "support"
        showToast("Email us at cheesetv795@gmail.com")
    else if id = "license"
        showChoice("info", "License & credits", ["CheeseTV for Roku " + m.version + " - MIT License.", "Interface font: Inter, (c) The Inter Project Authors, SIL Open Font License 1.1.", "CheeseTV is a media player and does not provide or include any channels or content.", "The CheeseTV name and logo are not covered by the MIT License."], ["OK"])
    end if
end sub

' ---------------- remote keys ----------------
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.loading.visible
        ' 2.0.2: Back cancels a slow search / series load instead of being ignored
        if key = "back" and (m.screen = "main" or m.screen = "series")
            m.searchReq = -1
            m.seriesReq = -1
            setLoading(false)
        end if
        return key = "back"
    end if
    s = m.screen
    if s = "player" then return playerKey(key)
    if s = "welcome"
        if key = "back"
            askExit()
            return true
        end if
        return false
    end if
    if s = "playlists" then return playlistsKey(key)
    if s = "form" then return formKey(key)
    if s = "series"
        if key = "right" and m.seasons.hasFocus()
            if m.episodes.content <> invalid and m.episodes.content.getChildCount() > 0 then m.episodes.setFocus(true)
            return true
        else if key = "left" and m.episodes.hasFocus()
            m.seasons.setFocus(true)
            return true
        else if key = "options"
            toggleFav(m.seriesItem)
            return true
        else if key = "back"
            closeSeries()
            return true
        end if
        return false
    end if
    if s <> "main" then return false
    ' --- main screen ---
    if m.nav.hasFocus()
        if key = "down"
            focusContent()
            return true
        else if key = "back"
            if m.tab <> "home"
                showTab("home", false)
            else
                askExit()
            end if
            return true
        end if
        return false
    end if
    t = m.tab
    if t = "guide" then return guideKey(key)
    if key = "options"
        it = invalid
        if m.rows.hasFocus() then it = m.heroItem
        if m.grid.hasFocus() then it = gridFocusedItem()
        if it <> invalid then toggleFav(it)
        return true
    end if
    if t = "home"
        if key = "up" or key = "back"
            m.nav.setFocus(true)
            return true
        end if
    else if t = "live" or t = "movies" or t = "series" or t = "search"
        if m.grid.hasFocus() and (key = "up" or key = "back")
            m.chips.setFocus(true)
            return true
        else if m.chips.hasFocus()
            if key = "up" or key = "back"
                m.nav.setFocus(true)
                return true
            else if key = "down"
                if m.grid.content <> invalid and m.grid.content.getChildCount() > 0 then m.grid.setFocus(true)
                return true
            end if
        end if
    else if t = "settings"
        if key = "up" or key = "back" or key = "left"
            m.nav.setFocus(true)
            return true
        end if
    end if
    return false
end function
