' CheeseTV for Roku - main scene logic. MIT License, (c) 2026 CheeseTV (watchcheesetv.com).
' Ships EMPTY: the user enters their own M3U URL or Xtream Codes login; it is saved in the registry.

sub init()
    m.top.backgroundColor = "0x0B1630FF"
    m.top.backgroundUri = ""
    m.loginGroup = m.top.findNode("loginGroup")
    m.homeGroup = m.top.findNode("homeGroup")
    m.browseGroup = m.top.findNode("browseGroup")
    m.aboutGroup = m.top.findNode("aboutGroup")
    m.header = m.top.findNode("header")
    m.loginMenu = m.top.findNode("loginMenu")
    m.loginMsg = m.top.findNode("loginMsg")
    m.homeGrid = m.top.findNode("homeGrid")
    m.acctLine = m.top.findNode("acctLine")
    m.catList = m.top.findNode("catList")
    m.itemList = m.top.findNode("itemList")
    m.itemsEmpty = m.top.findNode("itemsEmpty")
    m.browseTitle = m.top.findNode("browseTitle")
    m.infoPoster = m.top.findNode("infoPoster")
    m.infoTitle = m.top.findNode("infoTitle")
    m.infoDesc = m.top.findNode("infoDesc")
    m.aboutMenu = m.top.findNode("aboutMenu")
    m.aboutAcct = m.top.findNode("aboutAcct")
    m.video = m.top.findNode("video")
    m.osd = m.top.findNode("osd")
    m.osdTitle = m.top.findNode("osdTitle")
    m.osdEpg = m.top.findNode("osdEpg")
    m.osdHint = m.top.findNode("osdHint")
    m.pStatus = m.top.findNode("pStatus")
    m.loading = m.top.findNode("loading")
    m.loadingText = m.top.findNode("loadingText")
    m.clock = m.top.findNode("clock")
    m.top.findNode("spinner").poster.uri = "pkg:/images/spinner.png"

    m.retryTimer = m.top.findNode("retryTimer")
    m.catTimer = m.top.findNode("catTimer")
    m.epgTimer = m.top.findNode("epgTimer")
    m.osdTimer = m.top.findNode("osdTimer")
    clockTimer = m.top.findNode("clockTimer")

    ' home tiles
    tiles = CreateObject("roSGNode", "ContentNode")
    for each t in [["Live TV", "live"], ["Movies", "movies"], ["Series", "series"], ["Settings & About", "settings"]]
        c = tiles.createChild("ContentNode")
        c.title = t[0]
        c.HDPosterUrl = "pkg:/images/tile_" + t[1] + ".png"
        c.addFields({ go: t[1] })
    end for
    m.homeGrid.content = tiles

    m.loginMenu.observeField("itemSelected", "onLoginSelected")
    m.homeGrid.observeField("itemSelected", "onHomeSelected")
    m.aboutMenu.observeField("itemSelected", "onAboutSelected")
    m.catList.observeField("itemFocused", "onCatFocused")
    m.itemList.observeField("itemFocused", "onItemFocused")
    m.itemList.observeField("itemSelected", "onItemSelected")
    m.video.observeField("state", "onVideoState")
    m.retryTimer.observeField("fire", "startPlayback")
    m.catTimer.observeField("fire", "loadItems")
    m.epgTimer.observeField("fire", "loadEpg")
    m.osdTimer.observeField("fire", "hideOsd")
    clockTimer.observeField("fire", "updateClock")
    clockTimer.control = "start"
    updateClock()

    m.state = ""
    m.reqId = 0
    m.provider = invalid
    m.m3u = invalid
    m.inEpisodes = false
    m.retries = 0
    m.useAlt = false

    m.account = loadAccount()
    if m.account = invalid
        showLogin()
    else
        connect(m.account)
    end if
end sub

' ---------------- storage ----------------
function loadAccount() as dynamic
    sec = CreateObject("roRegistrySection", "CheeseTV")
    if not sec.Exists("account") then return invalid
    a = ParseJson(sec.Read("account"))
    if a = invalid or type(a) <> "roAssociativeArray" then return invalid
    return a
end function

sub saveAccount(a as object)
    sec = CreateObject("roRegistrySection", "CheeseTV")
    sec.Write("account", FormatJson(a))
    sec.Flush()
end sub

sub clearAccount()
    sec = CreateObject("roRegistrySection", "CheeseTV")
    sec.Delete("account")
    sec.Flush()
end sub

' ---------------- helpers ----------------
sub updateClock()
    d = CreateObject("roDateTime")
    d.ToLocalTime()
    h = d.GetHours()
    mi = d.GetMinutes()
    hs = StrI(h).Trim()
    ms = StrI(mi).Trim()
    if h < 10 then hs = "0" + hs
    if mi < 10 then ms = "0" + ms
    m.clock.text = hs + ":" + ms
end sub

sub setLoading(on as boolean, text = "Loading..." as string)
    m.loadingText.text = text
    m.loading.visible = on
end sub

sub hideAll()
    m.loginGroup.visible = false
    m.homeGroup.visible = false
    m.browseGroup.visible = false
    m.aboutGroup.visible = false
end sub

function api(kind as string, extra as object, callback as string) as object
    m.reqId = m.reqId + 1
    t = CreateObject("roSGNode", "ApiTask")
    r = { id: m.reqId, kind: kind, account: m.account }
    r.Append(extra)
    t.request = r
    t.observeField("response", callback)
    t.control = "RUN"
    return t
end function

' ---------------- login ----------------
sub showLogin(msg = "" as string)
    hideAll()
    m.state = "login"
    m.loginMsg.text = msg
    m.loginGroup.visible = true
    m.loginMenu.setFocus(true)
end sub

sub onLoginSelected()
    if m.loginMenu.itemSelected = 0
        m.pending = { type: "xtream", server: "", user: "", pass: "" }
        m.kbStep = "server"
        prev = m.account
        if prev <> invalid and prev.type = "xtream" then m.pending = { type: "xtream", server: prev.server, user: prev.user, pass: "" }
        askKeyboard("Xtream Codes - Server URL", "Example: http://server.example:8080", m.pending.server, "generic")
    else
        m.pending = { type: "m3u", url: "" }
        prev = m.account
        if prev <> invalid and prev.type = "m3u" then m.pending.url = prev.url
        m.kbStep = "url"
        askKeyboard("M3U playlist URL", "Enter the full playlist link from your provider (http:// or https://)", m.pending.url, "generic")
    end if
end sub

sub askKeyboard(title as string, message as string, text as string, domain as string)
    dlg = CreateObject("roSGNode", "StandardKeyboardDialog")
    dlg.title = title
    dlg.message = [message]
    dlg.buttons = ["OK", "Cancel"]
    dlg.keyboardDomain = domain
    dlg.text = text
    dlg.observeField("buttonSelected", "onKeyboardButton")
    dlg.observeField("wasClosed", "onKeyboardClosed")
    m.top.dialog = dlg
    m.kb = dlg
end sub

sub onKeyboardClosed(ev as object)
    ' fires when the user presses Back on the keyboard dialog
    node = ev.getRoSGNode()
    if m.kb <> invalid and node <> invalid and node.isSameNode(m.kb)
        m.kb = invalid
        m.top.dialog = invalid
        if m.state = "login" then m.loginMenu.setFocus(true)
    end if
end sub

sub onKeyboardButton()
    dlg = m.kb
    if dlg = invalid then return
    text = dlg.text.Trim()
    cancel = dlg.buttonSelected <> 0
    dlg.unobserveField("wasClosed")
    dlg.unobserveField("buttonSelected")
    dlg.close = true
    m.top.dialog = invalid
    m.kb = invalid
    if cancel
        m.loginMenu.setFocus(true)
        return
    end if
    s = m.kbStep
    if s = "url"
        low = LCase(text)
        if Left(low, 7) <> "http://" and Left(low, 8) <> "https://"
            m.loginMsg.text = "Please enter a playlist URL starting with http:// or https://"
            m.loginMenu.setFocus(true)
            return
        end if
        m.pending.url = text
        tryLogin(m.pending)
    else if s = "server"
        if text = ""
            m.loginMenu.setFocus(true)
            return
        end if
        m.pending.server = text
        m.kbStep = "user"
        askKeyboard("Xtream Codes - Username", "Server: " + text, m.pending.user, "generic")
    else if s = "user"
        if text = ""
            m.loginMenu.setFocus(true)
            return
        end if
        m.pending.user = text
        m.kbStep = "pass"
        askKeyboard("Xtream Codes - Password", "Username: " + text, "", "password")
    else if s = "pass"
        m.pending.pass = text
        tryLogin(m.pending)
    end if
end sub

sub tryLogin(acc as object)
    m.loginMsg.text = ""
    m.account = acc
    m.isNewLogin = true
    connect(acc)
end sub

sub connect(acc as object)
    m.account = acc
    if acc.type = "xtream" then setLoading(true, "Signing in...") else setLoading(true, "Loading playlist...")
    api("login", {}, "onLoginResponse")
end sub

sub onLoginResponse(ev as object)
    res = ev.getData()
    setLoading(false)
    if not res.ok
        m.provider = invalid
        showLogin(res.error)
        return
    end if
    m.provider = m.account.type
    if m.account.type = "m3u"
        m.m3u = res.data
    else
        m.m3u = invalid
    end if
    m.acctInfo = res.data.info
    saveAccount(m.account)
    showHome()
end sub

' ---------------- home ----------------
sub showHome()
    hideAll()
    m.state = "home"
    if m.account.type = "xtream"
        label = "Xtream: " + m.account.server + " (" + m.account.user + ")"
    else
        label = "Playlist: " + Left(m.account.url, 70)
    end if
    m.acctLine.text = label + "   " + m.acctInfo
    m.homeGroup.visible = true
    m.homeGrid.setFocus(true)
end sub

sub onHomeSelected()
    go = m.homeGrid.content.getChild(m.homeGrid.itemSelected).go
    if go = "settings" then showAbout() else showBrowse(go)
end sub

' ---------------- about ----------------
sub showAbout()
    hideAll()
    m.state = "about"
    if m.account.type = "xtream"
        m.aboutAcct.text = "Xtream: " + m.account.server + " (" + m.account.user + ")" + Chr(10) + m.acctInfo
    else
        m.aboutAcct.text = "Playlist: " + Left(m.account.url, 80) + Chr(10) + m.acctInfo
    end if
    m.aboutGroup.visible = true
    m.aboutMenu.jumpToItem = 0
    m.aboutMenu.setFocus(true)
end sub

sub onAboutSelected()
    i = m.aboutMenu.itemSelected
    if i = 0
        showLogin()
    else if i = 1
        clearAccount()
        m.account = invalid
        m.provider = invalid
        m.m3u = invalid
        showLogin("Playlist removed.")
    else
        showHome()
    end if
end sub

' ---------------- browse ----------------
sub showBrowse(mode as string)
    hideAll()
    m.state = "browse"
    m.mode = mode
    m.inEpisodes = false
    titles = { live: "Live TV", movies: "Movies", series: "Series" }
    m.browseTitle.text = "- " + titles[mode]
    m.browseGroup.visible = true
    m.itemList.content = CreateObject("roSGNode", "ContentNode")
    clearInfo()
    if m.m3u <> invalid
        m.catList.content = m.m3u[mode].cats
        m.catList.jumpToItem = 0
        m.catList.setFocus(true)
        if m.catList.content.getChildCount() = 0 then m.itemsEmpty.text = "Nothing in this section." else loadItems()
    else
        m.catList.content = CreateObject("roSGNode", "ContentNode")
        setLoading(true)
        m.catList.setFocus(true)
        api("cats", { mode: mode }, "onCats")
    end if
end sub

sub onCats(ev as object)
    res = ev.getData()
    setLoading(false)
    if m.state <> "browse" then return
    m.catList.content = res.data
    m.catList.jumpToItem = 0
    m.catList.setFocus(true)
    if not res.ok then m.itemsEmpty.text = res.error
    loadItems()
end sub

sub onCatFocused()
    if m.state <> "browse" then return
    m.catTimer.control = "stop"
    m.catTimer.control = "start"
end sub

sub loadItems()
    if m.state <> "browse" or m.catList.content = invalid then return
    idx = m.catList.itemFocused
    if idx < 0 or idx >= m.catList.content.getChildCount() then return
    cat = m.catList.content.getChild(idx)
    m.inEpisodes = false
    if m.m3u <> invalid
        list = m.m3u[m.mode].lists[cat.catId.ToInt()]
        setItems(list, "")
    else
        m.itemsEmpty.text = "Loading..."
        m.itemList.content = CreateObject("roSGNode", "ContentNode")
        m.itemsReq = api("items", { mode: m.mode, catId: cat.catId }, "onItems").request.id
    end if
end sub

sub onItems(ev as object)
    res = ev.getData()
    if res.id <> m.itemsReq or m.state <> "browse" then return
    err = ""
    if not res.ok then err = res.error
    setItems(res.data, err)
end sub

sub setItems(list as object, err as string)
    m.itemList.content = list
    m.itemList.jumpToItem = 0
    if list.getChildCount() = 0
        if err <> "" then m.itemsEmpty.text = err else m.itemsEmpty.text = "No items in this category."
        clearInfo()
    else
        m.itemsEmpty.text = ""
        showInfo(list.getChild(0))
    end if
end sub

sub clearInfo()
    m.infoPoster.uri = ""
    m.infoTitle.text = ""
    m.infoDesc.text = ""
end sub

sub onItemFocused()
    if m.itemList.content = invalid then return
    it = m.itemList.content.getChild(m.itemList.itemFocused)
    if it <> invalid then showInfo(it)
end sub

sub showInfo(it as object)
    m.infoTitle.text = it.title
    m.infoPoster.uri = it.HDPosterUrl
    m.infoDesc.text = it.description
    m.epgTimer.control = "stop"
    if m.account.type = "xtream" and it.kind = "live"
        m.epgFor = it.sid
        m.epgTarget = "info"
        m.epgTimer.control = "start"
    end if
end sub

sub loadEpg()
    api("epg", { streamId: m.epgFor }, "onEpg")
end sub

sub onEpg(ev as object)
    res = ev.getData()
    if res.data = invalid or res.data.text = "" then return
    if res.data.streamId <> m.epgFor then return
    if m.epgTarget = "osd" then m.osdEpg.text = res.data.text else m.infoDesc.text = res.data.text
end sub

sub onItemSelected()
    it = m.itemList.content.getChild(m.itemList.itemSelected)
    if it = invalid then return
    if it.kind = "series"
        m.savedSeries = { content: m.itemList.content, index: m.itemList.itemSelected }
        setLoading(true, "Loading episodes...")
        api("episodes", { seriesId: it.sid }, "onEpisodes")
    else
        playItem(m.itemList.content, m.itemList.itemSelected)
    end if
end sub

sub onEpisodes(ev as object)
    res = ev.getData()
    setLoading(false)
    if not res.ok
        m.infoDesc.text = res.error
        return
    end if
    m.inEpisodes = true
    setItems(res.data, "")
    m.itemList.setFocus(true)
end sub

' ---------------- player ----------------
sub playItem(list as object, index as integer)
    m.playList = list
    m.playIndex = index
    m.retries = 0
    m.useAlt = false
    m.state = "player"
    m.video.visible = true
    startPlayback()
    showOsd()
end sub

sub startPlayback()
    it = m.playList.getChild(m.playIndex)
    if it = invalid then return
    c = CreateObject("roSGNode", "ContentNode")
    c.title = it.title
    c.url = it.url
    c.streamFormat = it.streamFormat
    if m.useAlt and it.altUrl <> invalid and it.altUrl <> ""
        c.url = it.altUrl
        c.streamFormat = it.altFmt
    end if
    if it.kind = "live" then c.Live = true
    m.video.control = "stop"
    m.video.content = c
    m.video.control = "play"
    m.video.setFocus(true)
end sub

sub onVideoState()
    if m.state <> "player" then return
    st = m.video.state
    if st = "playing"
        m.retries = 0
        m.pStatus.visible = false
    else if st = "buffering"
        m.pStatus.text = "Buffering..."
        m.pStatus.visible = true
    else if st = "error" or (st = "finished" and isLive())
        if m.retries < 5
            m.retries = m.retries + 1
            if m.retries = 2 then m.useAlt = not m.useAlt
            m.pStatus.text = "Reconnecting... (" + StrI(m.retries).Trim() + "/5)"
            m.pStatus.visible = true
            m.retryTimer.duration = m.retries
            m.retryTimer.control = "start"
        else
            m.pStatus.text = "Stream unavailable. Press OK to retry."
            m.pStatus.visible = true
        end if
    else if st = "finished"
        stopPlayback()
    end if
end sub

function isLive() as boolean
    it = m.playList.getChild(m.playIndex)
    return it <> invalid and it.kind = "live"
end function

sub showOsd()
    it = m.playList.getChild(m.playIndex)
    m.osdTitle.text = it.title
    m.osdEpg.text = ""
    if it.kind = "live"
        m.osdHint.text = "Up/Down change channel - Back close"
        if m.account.type = "xtream"
            m.epgFor = it.sid
            m.epgTarget = "osd"
            loadEpg()
        end if
    else
        m.osdHint.text = "OK pause - Left/Right seek - Back close"
    end if
    m.osd.visible = true
    m.osdTimer.control = "stop"
    m.osdTimer.control = "start"
end sub

sub hideOsd()
    m.osd.visible = false
end sub

sub zap(d as integer)
    n = m.playList.getChildCount()
    if n = 0 then return
    m.playIndex = (m.playIndex + d + n) mod n
    m.retries = 0
    m.useAlt = false
    m.itemList.jumpToItem = m.playIndex
    startPlayback()
    showOsd()
end sub

sub stopPlayback()
    m.retryTimer.control = "stop"
    m.video.control = "stop"
    m.video.visible = false
    m.osd.visible = false
    m.pStatus.visible = false
    m.state = "browse"
    m.itemList.setFocus(true)
end sub

' ---------------- remote keys ----------------
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.state = "player"
        if key = "back"
            stopPlayback()
            return true
        end if
        if isLive()
            if key = "up"
                zap(-1)
                return true
            else if key = "down"
                zap(1)
                return true
            else if key = "OK" or key = "info"
                if m.retries >= 5
                    m.retries = 0
                    startPlayback()
                end if
                showOsd()
                return true
            end if
        else if key = "OK" and m.retries >= 5
            m.retries = 0
            startPlayback()
            return true
        end if
        return false
    else if m.state = "browse"
        if key = "right" and m.catList.hasFocus()
            if m.itemList.content <> invalid and m.itemList.content.getChildCount() > 0 then m.itemList.setFocus(true)
            return true
        else if key = "left" and m.itemList.hasFocus()
            if not m.inEpisodes then m.catList.setFocus(true)
            return true
        else if key = "back"
            if m.inEpisodes
                m.inEpisodes = false
                m.itemList.content = m.savedSeries.content
                m.itemList.jumpToItem = m.savedSeries.index
                m.itemList.setFocus(true)
            else if m.itemList.hasFocus()
                m.catList.setFocus(true)
            else
                showHome()
            end if
            return true
        end if
    else if m.state = "about"
        if key = "back"
            showHome()
            return true
        end if
    else if m.state = "login"
        if key = "back" and m.provider <> invalid
            showHome()
            return true
        end if
    end if
    return false
end function
