' CheeseTV: tile logic. MIT License, (c) 2026 CheeseTV.
sub init()
    m.body = m.top.findNode("body")
    m.card = m.top.findNode("card")
    m.glyph = m.top.findNode("glyph")
    m.art = m.top.findNode("art")
    m.title = m.top.findNode("title")
    m.sub = m.top.findNode("sub")
    m.center = m.top.findNode("center")
    m.star = m.top.findNode("star")
    m.cu = m.top.findNode("cu")
    m.ring = m.top.findNode("ring")
    m.liveDot = m.top.findNode("liveDot")
    m.art.observeField("loadStatus", "onArt")
    m.content = invalid
    m.w = 300
    m.h = 210
end sub

sub onContent()
    if m.content <> invalid
        m.content.unobserveFieldScoped("epg")
        m.content.unobserveFieldScoped("fav")
    end if
    m.content = m.top.itemContent
    if m.content = invalid then return
    m.content.observeFieldScoped("epg", "onMeta")
    m.content.observeFieldScoped("fav", "onMeta")
    layout()
end sub

function kindOf() as string
    c = m.content
    if c = invalid then return ""
    k = c.kind
    if k = invalid then return ""
    return k
end function

sub layout()
    if m.top.width > 0 then m.w = m.top.width
    if m.top.height > 0 then m.h = m.top.height
    c = m.content
    if c = invalid then return
    w = m.w
    h = m.h
    k = kindOf()
    m.body.scaleRotateCenter = [w / 2, h / 2]
    m.card.width = w
    m.card.height = h
    m.ring.width = w + 10
    m.ring.height = h + 10
    m.ring.translation = [-5, -5]
    m.star.translation = [w - 44, 10]
    m.cu.translation = [w - 44, 10]
    m.cu.visible = false
    m.liveDot.visible = false
    if k = "loading" or k = "hint" or k = "action"
        m.art.visible = false
        m.glyph.visible = false
        m.title.visible = false
        m.sub.visible = false
        m.center.visible = true
        m.center.width = w - 30
        m.center.height = h - 20
        m.center.translation = [15, 10]
        m.center.text = c.title
        if k = "loading" then m.center.color = "0x6E7891FF" else m.center.color = "0xF5C242FF"
        m.card.blendColor = "0x111B33FF"
        if k = "action" then m.card.blendColor = "0x2A2A1AFF"
        m.star.visible = false
        return
    end if
    m.center.visible = false
    m.title.visible = true
    m.sub.visible = true
    m.card.blendColor = "0x111B33FF"
    m.title.text = c.title
    if k = "live"
        artH = h - 92
        m.art.loadDisplayMode = "scaleToFit"
        m.art.width = w - 60
        m.art.height = artH - 20
        m.art.translation = [30, 18]
        m.glyph.width = 80
        m.glyph.height = 80
        m.glyph.translation = [(w - 80) / 2, (artH - 80) / 2 + 6]
        m.title.width = w - 36
        m.title.translation = [18, h - 76]
        m.sub.width = w - 36
        m.sub.translation = [18, h - 42]
        m.liveDot.translation = [18, 18]
        m.liveDot.visible = true
    else
        ' poster: artwork fills the card, title underneath inside the card
        artH = h - 64
        m.art.loadDisplayMode = "scaleToFill"
        if k = "episode" then m.art.loadDisplayMode = "scaleToFit"
        m.art.width = w
        m.art.height = artH
        m.art.translation = [0, 0]
        m.glyph.width = 72
        m.glyph.height = 72
        m.glyph.translation = [(w - 72) / 2, (artH - 72) / 2]
        m.title.width = w - 24
        m.title.translation = [12, artH + 6]
        m.sub.width = w - 24
        m.sub.translation = [12, artH + 34]
    end if
    uri = c.HDPosterUrl
    m.glyph.visible = true
    m.art.visible = uri <> ""
    if m.art.uri <> uri then m.art.uri = uri
    if uri <> "" and m.art.loadStatus = "ready" then m.glyph.visible = false
    onMeta()
end sub

sub onArt()
    st = m.art.loadStatus
    m.glyph.visible = not (st = "ready")
end sub

sub onMeta()
    c = m.content
    if c = invalid then return
    k = kindOf()
    if k = "loading" or k = "hint" or k = "action" then return
    f = c.fav
    m.star.visible = (f = true)
    ar = c.archive
    m.cu.visible = (ar <> invalid and ar > 0)
    if m.star.visible then m.cu.translation = [m.w - 84, 10] else m.cu.translation = [m.w - 44, 10]
    s = ""
    if c.epg <> invalid and c.epg <> "" then s = c.epg
    if s = "" and k = "live" then s = "Live"
    if s = "" and c.description <> invalid then s = c.description
    m.sub.text = s
end sub

sub onFocus()
    has = m.top.rowListHasFocus or m.top.gridHasFocus
    p = m.top.focusPercent
    if not has then p = 0
    m.ring.opacity = p
    sc = 1 + 0.06 * p
    m.body.scale = [sc, sc]
    if p > 0.5 then m.title.color = "0xF5C242FF" else m.title.color = "0xF4F6FBFF"
    k = kindOf()
    if k = "loading" or k = "hint" then return
    if p > 0.5 then m.card.blendColor = "0x1A2747FF" else m.card.blendColor = "0x111B33FF"
end sub
