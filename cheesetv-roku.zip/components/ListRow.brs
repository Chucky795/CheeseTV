' CheeseTV: list row. MIT License, (c) 2026 CheeseTV.
sub init()
    m.section = m.top.findNode("section")
    m.bg = m.top.findNode("bg")
    m.ring = m.top.findNode("ring")
    m.icon = m.top.findNode("icon")
    m.title = m.top.findNode("title")
    m.desc = m.top.findNode("desc")
    m.arrow = m.top.findNode("arrow")
    m.w = 1200
    m.h = 110
end sub

function fld(name as string) as string
    c = m.top.itemContent
    if c = invalid then return ""
    v = c.getField(name)
    if v = invalid then return ""
    return v
end function

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.title.text = c.title
    m.desc.text = c.description
    m.section.text = fld("section")
    m.icon.text = fld("icon")
    st = fld("tone")
    if st = "error"
        m.base = "0x8E1F2AFF"
    else if st = "accent"
        m.base = "0x2A3A66FF"
    else
        m.base = "0x111B33FF"
    end if
    m.arrow.visible = fld("arrow") = "1"
    layout()
    onFocus()
end sub

sub layout()
    if m.top.width > 0 then m.w = m.top.width
    if m.top.height > 0 then m.h = m.top.height
    top = 0
    if m.section.text <> "" then top = 34
    h = m.h - top - 6
    m.section.translation = [8, 0]
    m.bg.translation = [0, top]
    m.bg.width = m.w
    m.bg.height = h
    m.ring.translation = [-4, top - 4]
    m.ring.width = m.w + 8
    m.ring.height = h + 8
    ix = 24
    if m.icon.text <> ""
        m.icon.translation = [16, top]
        m.icon.width = 60
        m.icon.height = h
        ix = 88
    end if
    m.arrow.translation = [m.w - 70, top]
    m.arrow.width = 50
    m.arrow.height = h
    m.title.width = m.w - ix - 90
    m.desc.width = m.w - ix - 90
    if m.desc.text = ""
        m.title.translation = [ix, top + (h - 36) / 2]
    else
        m.title.translation = [ix, top + 12]
        m.desc.translation = [ix, top + 50]
    end if
end sub

sub onFocus()
    p = m.top.focusPercent
    if not m.top.listHasFocus then p = 0
    m.ring.opacity = p
    if m.base = invalid then m.base = "0x111B33FF"
    if p > 0.5 and m.base = "0x111B33FF" then m.bg.blendColor = "0x1A2747FF" else m.bg.blendColor = m.base
end sub
