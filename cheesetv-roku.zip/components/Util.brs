' CheeseTV for Roku - shared helpers (render thread + tasks). MIT License, (c) 2026 CheeseTV.

function toStr(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInt" or t = "roInteger" or t = "Integer" or t = "LongInteger" or t = "roLongInteger" then return v.ToStr()
    if t = "roFloat" or t = "Float" or t = "roDouble" or t = "Double"
        if v = Int(v) then return Int(v).ToStr()
        return Str(v).Trim()
    end if
    if t = "roBoolean" or t = "Boolean"
        if v then return "true"
        return "false"
    end if
    return ""
end function

function toInt(v as dynamic) as integer
    s = toStr(v)
    if s = "" then return 0
    return s.ToInt()
end function

function esc(s as string) as string
    return CreateObject("roUrlTransfer").Escape(s)
end function

' Normalises what the user typed as the Xtream server ("host:port", "http://host:port/", ".../player_api.php").
function xBase(acc as object) as string
    s = toStr(acc.server).Trim()
    low = LCase(s)
    if Left(low, 7) <> "http://" and Left(low, 8) <> "https://" then s = "http://" + s
    r = CreateObject("roRegex", "/(player_api\.php|get\.php|panel_api\.php|xmltv\.php).*$", "i")
    s = r.Replace(s, "")
    q = Instr(1, s, "?")
    if q > 0 then s = Left(s, q - 1)
    while Right(s, 1) = "/"
        s = Left(s, Len(s) - 1)
    end while
    return s
end function

function xApi(acc as object, extra as string) as string
    return xBase(acc) + "/player_api.php?username=" + esc(toStr(acc.user)) + "&password=" + esc(toStr(acc.pass)) + extra
end function

function xUp(acc as object) as string
    return "/" + esc(toStr(acc.user)) + "/" + esc(toStr(acc.pass)) + "/"
end function

' Live URLs. pref = "auto" (HLS first, Roku plays HLS best, falls back to MPEG-TS), "hls" (HLS only)
' or "ts" (MPEG-TS first, falls back to HLS). Returns primary + fallback.
function liveUrls(acc as object, sid as string, pref as string) as object
    b = xBase(acc) + "/live" + xUp(acc) + sid
    if pref = "ts" then return { url: b + ".ts", fmt: "ts", alt: b + ".m3u8", altFmt: "hls" }
    if pref = "hls" then return { url: b + ".m3u8", fmt: "hls", alt: "", altFmt: "" }
    return { url: b + ".m3u8", fmt: "hls", alt: b + ".ts", altFmt: "ts" }
end function

' Xtream catch-up (tv_archive) URLs:
'   {base}/timeshift/{user}/{pass}/{minutes}/{YYYY-MM-DD:HH-MM}/{stream_id}.m3u8 (or .ts)
' The start time is written in the server's own clock: srvOffset = server local time - UTC (seconds).
function catchupStamp(startTs as integer, srvOffset as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(startTs + srvOffset)
    return d.GetYear().ToStr() + "-" + pad2(d.GetMonth()) + "-" + pad2(d.GetDayOfMonth()) + ":" + pad2(d.GetHours()) + "-" + pad2(d.GetMinutes())
end function

function catchupUrls(acc as object, sid as string, startTs as integer, endTs as integer, srvOffset as integer, pref as string) as object
    mins = Int((endTs - startTs) / 60)
    if mins < 1 then mins = 1
    b = xBase(acc) + "/timeshift" + xUp(acc) + mins.ToStr() + "/" + catchupStamp(startTs, srvOffset) + "/" + sid
    if pref = "ts" then return { url: b + ".ts", fmt: "ts", alt: b + ".m3u8", altFmt: "hls" }
    return { url: b + ".m3u8", fmt: "hls", alt: b + ".ts", altFmt: "ts" }
end function

function vodUrl(acc as object, sid as string, ext as string) as string
    if ext = "" then ext = "mp4"
    return xBase(acc) + "/movie" + xUp(acc) + sid + "." + ext
end function

function episodeUrl(acc as object, eid as string, ext as string) as string
    if ext = "" then ext = "mp4"
    return xBase(acc) + "/series" + xUp(acc) + eid + "." + ext
end function

function fmtFor(ext as string) as string
    e = LCase(ext)
    if e = "m3u8" or e = "m3u" then return "hls"
    if e = "mkv" then return "mkv"
    if e = "mpd" then return "dash"
    if e = "ts" then return "ts"
    if e = "mp3" then return "mp3"
    return "mp4"
end function

function b64(s as string) as string
    if s = "" then return ""
    r = CreateObject("roRegex", "^[A-Za-z0-9+/]+={0,2}$", "")
    if not r.IsMatch(s) or (Len(s) mod 4) <> 0 then return s
    ba = CreateObject("roByteArray")
    ba.FromBase64String(s)
    out = ba.ToAsciiString()
    if out = "" then return s
    return out
end function

function nowSecs() as integer
    d = CreateObject("roDateTime")
    return d.AsSeconds()
end function

function pad2(n as integer) as string
    if n < 10 then return "0" + n.ToStr()
    return n.ToStr()
end function

' Local "h:mm AM" for an epoch time.
function hhmm(ts as integer) as string
    if ts <= 0 then return ""
    d = CreateObject("roDateTime")
    d.FromSeconds(ts)
    d.ToLocalTime()
    h = d.GetHours()
    ap = "AM"
    if h >= 12 then ap = "PM"
    h12 = h mod 12
    if h12 = 0 then h12 = 12
    return h12.ToStr() + ":" + pad2(d.GetMinutes()) + " " + ap
end function

' Offset of local time from UTC in seconds.
function tzOffset() as integer
    d = CreateObject("roDateTime")
    u = d.AsSeconds()
    d.ToLocalTime()
    return d.AsSeconds() - u
end function

' Epoch (UTC) of local midnight for "today + dayOffset".
function localMidnight(dayOffset as integer) as integer
    off = tzOffset()
    loc = nowSecs() + off
    mid = loc - (loc mod 86400)
    return mid - off + dayOffset * 86400
end function

function dayLabel(dayOffset as integer) as string
    if dayOffset = 0 then return "Today"
    if dayOffset = 1 then return "Tomorrow"
    d = CreateObject("roDateTime")
    d.FromSeconds(localMidnight(dayOffset) + 43200)
    d.ToLocalTime()
    wd = Left(d.GetWeekday(), 3)
    return wd + " " + d.GetDayOfMonth().ToStr()
end function

function minsText(secs as integer) as string
    m = Int(secs / 60)
    if m < 60 then return m.ToStr() + " min"
    return Int(m / 60).ToStr() + " h " + pad2(m mod 60) + " min"
end function

function httpGet(url as string, timeoutMs as integer) as dynamic
    ut = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    ut.SetMessagePort(port)
    ut.SetUrl(url)
    ut.AddHeader("User-Agent", playerAgent())
    if LCase(Left(url, 6)) = "https:"
        ut.SetCertificatesFile("common:/certs/ca-bundle.crt")
        ut.InitClientCertificates()
    end if
    ut.EnableEncodings(true)
    ut.RetainBodyOnError(false)
    ut.AddHeader("User-Agent", "CheeseTV-Roku/2.0")
    if not ut.AsyncGetToString() then return invalid
    msg = wait(timeoutMs, port)
    if type(msg) = "roUrlEvent"
        code = msg.GetResponseCode()
        if code >= 200 and code < 300 then return msg.GetString()
        return invalid
    end if
    ut.AsyncCancel()
    return invalid
end function

function getJson(url as string, timeoutMs as integer) as dynamic
    txt = httpGet(url, timeoutMs)
    if txt = invalid or txt = "" then return invalid
    return ParseJson(txt)
end function

' Item record (compact keys, also the registry format for Favorites / Recently watched):
'   k kind (live|movie|series|episode), i id, t title, g logo/poster, c category id
'   x container ext, u url (M3U only), f format, a fallback url, af fallback format, p resume position
' Builds a playable ContentNode from a record. acc = active playlist, pref = live format setting.
function recToNode(rec as object, acc as object, pref as string, parent as dynamic) as object
    if parent <> invalid
        it = parent.createChild("ContentNode")
    else
        it = CreateObject("roSGNode", "ContentNode")
    end if
    k = toStr(rec.k)
    sid = toStr(rec.i)
    it.title = toStr(rec.t)
    it.HDPosterUrl = toStr(rec.g)
    it.SDPosterUrl = it.HDPosterUrl
    if rec.d <> invalid then it.description = toStr(rec.d)
    url = toStr(rec.u)
    fmt = toStr(rec.f)
    alt = toStr(rec.a)
    altFmt = toStr(rec.af)
    if url = "" and acc <> invalid and toStr(acc.type) = "xtream" and sid <> ""
        if k = "live"
            lu = liveUrls(acc, sid, pref)
            url = lu.url : fmt = lu.fmt : alt = lu.alt : altFmt = lu.altFmt
        else if k = "movie"
            url = vodUrl(acc, sid, toStr(rec.x)) : fmt = fmtFor(toStr(rec.x))
        else if k = "episode"
            url = episodeUrl(acc, sid, toStr(rec.x)) : fmt = fmtFor(toStr(rec.x))
        end if
    else if url <> "" and k = "live" and pref = "ts" and altFmt = "ts" and alt <> "" and alt <> url
        ' M3U Xtream-style link rewritten to HLS: honour the MPEG-TS preference
        tmp = url : url = alt : alt = tmp
        tf = fmt : fmt = altFmt : altFmt = tf
    end if
    it.url = url
    it.streamFormat = fmt
    if k = "live" then it.Live = true
    it.addFields({ kind: k, sid: sid, cat: toStr(rec.c), ext: toStr(rec.x), altUrl: alt, altFmt: altFmt, epg: "", fav: false, pos: toInt(rec.p), extra: toStr(rec.e), archive: toInt(rec.ar), num: toStr(rec.n) })
    return it
end function

' Reverse of recToNode: compact record for the registry (no Xtream URLs => no credentials stored twice).
function nodeToRec(it as object, isXtream as boolean) as object
    rec = { k: it.kind, i: it.sid, t: Left(it.title, 60) }
    logo = it.HDPosterUrl
    if Len(logo) <= 200 then rec.g = logo
    if it.cat <> "" then rec.c = it.cat
    if it.ext <> "" then rec.x = it.ext
    if it.extra <> invalid and it.extra <> "" then rec.e = it.extra
    if it.archive <> invalid and it.archive > 0 then rec.ar = it.archive
    if it.num <> invalid and it.num <> "" then rec.n = it.num
    if not isXtream or it.sid = ""
        rec.u = it.url
        rec.f = it.streamFormat
        if it.altUrl <> "" then
            rec.a = it.altUrl
            rec.af = it.altFmt
        end if
    end if
    return rec
end function

function recKey(rec as object) as string
    if toStr(rec.i) <> "" then return toStr(rec.k) + ":" + toStr(rec.i)
    return toStr(rec.k) + ":t:" + Left(toStr(rec.t), 60)
end function

function nodeKey(it as object) as string
    if it.sid <> invalid and it.sid <> "" then return it.kind + ":" + it.sid
    return toStr(it.kind) + ":t:" + Left(toStr(it.title), 60)
end function

' CheeseTV 2.0.2: compact registry record for Favorites / Continue Watching. Roku gives a channel
' only 16 KB of registry in total, so only what is needed to show and play the item is kept.
function compactRec(it as object, isXtream as boolean) as object
    rec = { k: it.kind, i: it.sid, t: Left(toStr(it.title), 48) }
    logo = toStr(it.HDPosterUrl)
    if logo <> "" and Len(logo) <= 160 then rec.g = logo
    if toStr(it.ext) <> "" and Len(toStr(it.ext)) <= 5 then rec.x = it.ext
    if it.archive <> invalid and it.archive > 0 then rec.ar = it.archive
    if it.extra <> invalid and toStr(it.extra) <> "" and Len(toStr(it.extra)) <= 24 then rec.e = it.extra
    if not isXtream or toStr(it.sid) = ""
        rec.u = toStr(it.url)
        rec.f = toStr(it.streamFormat)
        if toStr(it.altUrl) <> "" and Len(toStr(it.altUrl)) <= 300
            rec.a = it.altUrl
            rec.af = it.altFmt
        end if
    end if
    return rec
end function

' Shrinks a record list until its JSON fits maxBytes: drops logos from the oldest entries first,
' then the oldest entries. Returns the (possibly new) list.
function fitRecs(list as object, maxBytes as integer) as object
    if list = invalid then return []
    if Len(FormatJson(list)) <= maxBytes then return list
    for i = list.count() - 1 to 0 step -1
        r = list[i]
        if r.g <> invalid then r.Delete("g")
        if r.c <> invalid then r.Delete("c")
        if r.n <> invalid then r.Delete("n")
        if Len(FormatJson(list)) <= maxBytes then return list
    end for
    while list.count() > 0 and Len(FormatJson(list)) > maxBytes
        list.Pop()
    end while
    return list
end function

' CheeseTV 2.0.2: same User-Agent as the Android app. Some IPTV panels block or throttle
' unknown agents (e.g. Roku's default) on live streams while VLC-style agents work.
function playerAgent() as string
    return "VLC/3.0.21 LibVLC/3.0.21"
end function
