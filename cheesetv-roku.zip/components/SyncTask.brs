' CheeseTV 2.0.4: sync worker. Jobs are { fn, body, id }; results only for sync_get.
' The anon key below is the public Supabase key: it can only call the 3 sync RPCs.
function syncAnon() as string
    return "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZybXR4cnR6d2VibGFrdXZrd29lIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI3MjcyMTAsImV4cCI6MjEwODMwMzIxMH0.PrQd5VwSHcWZF2FEIoboUes5PGlAUxbprSEaio-zGkQ"
end function

sub init()
    m.top.functionName = "syncLoop"
end sub

sub syncLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("job", port)
    while true
        msg = wait(0, port)
        if type(msg) = "roSGNodeEvent"
            job = msg.getData()
            if type(job) = "roAssociativeArray" and job.fn <> invalid
                data = syncPost(toStr(job.fn), job.body)
                if job.fn = "sync_get" then m.top.result = { id: job.id, ok: data <> invalid, data: data }
            end if
        end if
    end while
end sub

function syncPost(fn as string, body as object) as dynamic
    anon = syncAnon()
    t = CreateObject("roUrlTransfer")
    p = CreateObject("roMessagePort")
    t.SetMessagePort(p)
    t.SetUrl("https://vrmtxrtzweblakuvkwoe.supabase.co/rest/v1/rpc/" + fn)
    t.AddHeader("apikey", anon)
    t.AddHeader("Authorization", "Bearer " + anon)
    t.AddHeader("Content-Type", "application/json")
    t.SetCertificatesFile("common:/certs/ca-bundle.crt")
    t.InitClientCertificates()
    t.RetainBodyOnError(true)
    if not t.AsyncPostFromString(FormatJson(body)) then return invalid
    ev = wait(15000, p)
    if type(ev) <> "roUrlEvent"
        t.AsyncCancel()
        return invalid
    end if
    if ev.GetResponseCode() <> 200 then return invalid
    return ParseJson(ev.GetString())
end function

