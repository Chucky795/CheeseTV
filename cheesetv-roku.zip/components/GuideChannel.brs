' CheeseTV: guide channel cell. MIT License, (c) 2026 CheeseTV.
sub init()
    m.bg = m.top.findNode("bg")
    m.logoBg = m.top.findNode("logoBg")
    m.logo = m.top.findNode("logo")
    m.name = m.top.findNode("name")
    m.star = m.top.findNode("star")
    m.cu = m.top.findNode("cu")
    m.w = 330
    m.h = 100
end sub

sub onContent()
    c = m.top.content
    if c = invalid then return
    m.name.text = c.title
    m.logo.uri = c.HDPosterUrl
    f = c.fav
    m.star.visible = (f = true)
    ar = c.archive
    m.cu.visible = (ar <> invalid and ar > 0)
    layout()
end sub

sub layout()
    if m.top.width > 0 then m.w = m.top.width
    if m.top.height > 0 then m.h = m.top.height
    w = m.w
    h = m.h
    m.bg.width = w - 6
    m.bg.height = h - 6
    m.bg.translation = [0, 3]
    lw = Int((h - 22) * 1.4)
    m.logoBg.width = lw
    m.logoBg.height = h - 22
    m.logoBg.translation = [8, 11]
    m.logo.width = lw - 10
    m.logo.height = h - 32
    m.logo.translation = [13, 16]
    m.name.width = w - lw - 30
    m.name.height = h - 10
    m.name.translation = [lw + 18, 5]
    m.star.translation = [10, 12]
    m.cu.translation = [w - 38, h - 36]
end sub
