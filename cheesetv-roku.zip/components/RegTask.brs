' CheeseTV 2.0.2: registry writer task. Jobs are { key, value (JSON text) } and are written
' and flushed here, so a slow Flush on the TV's flash storage never freezes the remote.
sub init()
    m.top.functionName = "regLoop"
end sub

sub regLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("job", port)
    sec = CreateObject("roRegistrySection", "CheeseTV")
    while true
        msg = wait(0, port)
        if type(msg) = "roSGNodeEvent"
            job = msg.getData()
            if type(job) = "roAssociativeArray" and job.key <> invalid
                if job.value = invalid
                    sec.Delete(job.key)
                else
                    sec.Write(job.key, job.value)
                end if
                ok = sec.Flush()
                m.top.result = { key: job.key, ok: ok }
            end if
        end if
    end while
end sub
