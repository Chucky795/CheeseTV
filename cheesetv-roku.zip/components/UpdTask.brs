sub init()
    m.top.functionName = "checkVer"
end sub

sub checkVer()
    ut = CreateObject("roUrlTransfer")
    ut.SetCertificatesFile("common:/certs/ca-bundle.crt")
    ut.InitClientCertificates()
    ut.SetUrl("https://watchcheesetv.com/version.json?t=" + CreateObject("roDateTime").AsSeconds().ToStr())
    j = ParseJson(ut.GetToString())
    if type(j) = "roAssociativeArray" and j.roku <> invalid then m.top.latest = j.roku
end sub
