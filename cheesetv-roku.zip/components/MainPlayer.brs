' CheeseTV for Roku - player: live TV (channel up/down, pause, -10s / +30s, LIVE), catch-up and VOD.
' MIT License, (c) 2026 CheeseTV. No recording: Roku apps cannot record to the device.

sub initPlayer()
    m.video.notificationInterval = 1
    m.video.observeField("state", "onVideoState")
    m.video.observeField("position", "onVideoPosition")
    m.retryTimer.observeField("fire", "onRetry")
    m.stallTimer.observeField("fire", "onStallTick")
    m.osdTimer.observeField("fire", "hideOsd")
    m.ctrl.observeField("itemSelected", "onCtrlSelected")
    m.chList.observeField("itemSelected", "onChListSelected")
    ctrl = CreateObject("roSGNode", "ContentNode")
    for each b in [["-10s", "back"], ["Pause", "pause"], ["+30s", "fwd"], ["● LIVE", "live"], ["Channels", "list"]]
        c = ctrl.createChild("ContentNode")
        c.title = b[0]
        c.addFields({ chip: true, sel: false, act: b[1] })
    end for
    m.ctrl.content = ctrl
    m.playList = invalid
    m.playIdx = 0
    m.retries = 0
    m.variants = invalid
    m.variantsFor = ""
    m.failed = false
    m.dvr = false
    m.paused = false
end sub

function currentItem() as dynamic
    if m.playList = invalid then return invalid
    return m.playList.getChild(m.playIdx)
end function

function indexIn(list as object, it as object) as integer
    n = list.getChildCount()
    for i = 0 to n - 1
        if list.getChild(i).isSameNode(it) then return i
    end for
    return 0
end function

sub playItem(it as object, list as object)
    m.prevScreen = m.screen
    m.prevFocus = focusedNode()
    m.playList = list
    m.playIdx = indexIn(list, it)
    k = it.kind
    if k = "movie" or k = "episode"
        posS = recentPos(it)
        addRecent(it)
        if posS > 30
            m.resumePos = posS
            m.screen = "player"
            setPlayerChrome(true)
            showChoice("resume", it.title, ["Resume watching?"], ["Resume from " + clockText(posS), "Start over"])
            return
        end if
    else if k = "live"
        addRecent(it)
    end if
    beginPlayback(0)
end sub

sub playerResumeChoice(idx as integer)
    if idx = 0
        beginPlayback(m.resumePos)
    else if idx = 1
        beginPlayback(0)
    else
        ' dialog dismissed with Back
        setPlayerChrome(false)
        m.screen = m.prevScreen
        if m.prevFocus <> invalid then m.prevFocus.setFocus(true)
    end if
end sub

function clockText(secs as integer) as string
    h = Int(secs / 3600)
    mi = Int((secs mod 3600) / 60)
    se = secs mod 60
    if h > 0 then return h.ToStr() + ":" + pad2(mi) + ":" + pad2(se)
    return mi.ToStr() + ":" + pad2(se)
end function

' Full-screen player: hide the browse UI behind a black backdrop, put it back afterwards.
sub setPlayerChrome(on as boolean)
    if on
        if m.playerHidden = invalid
            m.playerHidden = []
            for each g in ["topBar", "homeGroup", "gridGroup", "guideGroup", "seriesGroup", "settingsGroup"]
                if m[g].visible
                    m.playerHidden.push(g)
                    m[g].visible = false
                end if
            end for
        end if
        m.top.findNode("playerBg").visible = true
        m.video.visible = true
    else
        m.video.visible = false
        m.top.findNode("playerBg").visible = false
        if m.playerHidden <> invalid
            for each g in m.playerHidden
                m[g].visible = true
            end for
            m.playerHidden = invalid
        end if
    end if
end sub

sub beginPlayback(startPos as integer)
    m.screen = "player"
    m.retries = 0
    setPlayerChrome(true)
    startPlayback(startPos)
    it = currentItem()
    if it <> invalid and it.kind = "live" then showOsd(false)
end sub

function isLive() as boolean
    it = currentItem()
    return it <> invalid and it.kind = "live"
end function

sub startPlayback(startPos = 0 as integer)
    it = currentItem()
    if it = invalid then return
    m.retryTimer.control = "stop"
    m.failed = false
    vkey = toStr(it.kind) + "|" + toStr(it.sid) + "|" + toStr(it.url)
    if m.variants = invalid or m.variantsFor <> vkey
        m.variants = playVariants(it)
        m.variantsFor = vkey
    end if
    vi = m.retries
    if vi >= m.variants.count() then vi = m.variants.count() - 1
    v = m.variants[vi]
    c = CreateObject("roSGNode", "ContentNode")
    c.title = it.title
    c.url = v.url
    c.streamFormat = v.fmt
    ' 2.0.2: VLC agent like the Android app; Roku follows HTTP redirects itself.
    c.HttpHeaders = ["User-Agent:" + playerAgent()]
    m.curVariant = v
    print "CheeseTV play attempt "; (vi + 1).ToStr(); "/"; m.variants.count().ToStr(); " fmt="; v.fmt
    live = (it.kind = "live")
    if live then c.Live = true
    if startPos > 0 then c.PlayStart = startPos
    m.dvr = false
    m.paused = false
    m.pauseBadge.visible = false
    m.bufSecs = 0
    m.window = 0
    m.video.enableUI = not live
    m.video.control = "stop"
    m.video.content = c
    m.video.control = "play"
    m.video.setFocus(true)
    m.stallTimer.control = "start"
    m.playingSecs = 0
    m.lastPos = -1
    m.samePosSecs = 0
    m.posMoved = false
    ' keep the "Trying another format…" line visible while the new attempt starts
    if m.retries = 0 then m.pStatus.visible = false
end sub

'2.0.2: the formats tried in order for one item (HLS first, then TS, then no extension,
' then HLS once more). Each attempt sets its streamFormat explicitly.
function MAX_TRIES() as integer
    if m.variants = invalid then return 1
    return m.variants.count()
end function

sub addVariant(v as object, url as dynamic, fmt as dynamic)
    if url = invalid or url = "" then return
    if fmt = invalid or fmt = "" then fmt = "hls"
    for each x in v
        if x.url = url and x.fmt = fmt then return
    end for
    v.push({ url: url, fmt: fmt })
end sub

function playVariants(it as object) as object
    v = []
    sid = toStr(it.sid)
    if it.kind = "live" and isX() and sid <> ""
        b = xBase(m.acc) + "/live" + xUp(m.acc) + sid
        if fmtPref() = "ts"
            addVariant(v, b + ".ts", "ts")
            addVariant(v, b + ".m3u8", "hls")
        else
            addVariant(v, b + ".m3u8", "hls")
            addVariant(v, b + ".ts", "ts")
        end if
        addVariant(v, b, "ts")
    else
        addVariant(v, it.url, it.streamFormat)
        addVariant(v, it.altUrl, it.altFmt)
    end if
    if v.count() = 0 then v.push({ url: toStr(it.url), fmt: "hls" })
    ' one more go with the first format (a live feed that was briefly down)
    if it.kind = "live" then v.push(v[0])
    return v
end function

' Short "Details" line for the status text, e.g. "HLS · error -3: ... (http 403)".
function errorDetail() as string
    code = m.video.errorCode
    msg = toStr(m.video.errorMsg)
    st = toStr(m.video.errorStr)
    d = ""
    if m.curVariant <> invalid then d = UCase(m.curVariant.fmt)
    if code <> invalid and code <> 0 then d = d + " · error " + code.ToStr()
    if msg <> "" then d = d + ": " + Left(msg, 80)
    if st <> "" then d = d + " (" + Left(st, 80) + ")"
    info = m.video.errorInfo
    if type(info) = "roAssociativeArray"
        if info.category <> invalid then d = d + " [" + toStr(info.category) + "]"
    end if
    return d
end function

sub onRetry()
    if m.screen <> "player" then return
    startPlayback(0)
end sub

sub onVideoState()
    if m.screen <> "player" then return
    st = m.video.state
    if st = "playing"
        ' retries reset after 20 s of real playback (onStallTick), not on the first frame
        m.bufSecs = 0
        m.paused = false
        m.pauseBadge.visible = false
        m.pStatus.visible = false
        setPauseLabel("Pause")
    else if st = "buffering"
        m.pStatus.text = "buffering"
        m.pStatus.visible = true
    else if st = "paused"
        m.paused = true
        setPauseLabel("Play")
    else if st = "error" or (st = "finished" and isLive())
        retryPlayback()
    else if st = "finished"
        it = currentItem()
        if it <> invalid and it.kind = "episode" and m.playIdx + 1 < m.playList.getChildCount()
            setRecentPos(it, 0)
            m.playIdx = m.playIdx + 1
            nx = currentItem()
            addRecent(nx)
            showToast("Playing next episode: " + nx.title)
            m.retries = 0
                    startPlayback(0)
        else
            if it <> invalid then setRecentPos(it, 0)
            stopPlayback(false)
        end if
    end if
end sub

sub retryPlayback()
    ' 2.0.2: never loops forever and never blocks: every retry is a Timer, Back always works.
    it = currentItem()
    detail = errorDetail()
    print "CheeseTV playback problem: "; detail
    if m.retries + 1 < MAX_TRIES()
        prev = m.curVariant
        m.retries = m.retries + 1
        nxt = m.variants[m.retries]
        if prev <> invalid and (nxt.fmt <> prev.fmt or nxt.url <> prev.url)
            m.pStatus.text = "Trying another format… (" + (m.retries + 1).ToStr() + "/" + MAX_TRIES().ToStr() + ")"
        else
            m.pStatus.text = "Reconnecting… (" + (m.retries + 1).ToStr() + "/" + MAX_TRIES().ToStr() + ")"
        end if
        if detail <> "" then m.pStatus.text = m.pStatus.text + Chr(10) + "Details: " + detail
        m.pStatus.visible = true
        m.video.control = "stop"
        d = m.retries
        if d > 3 then d = 3
        m.retryTimer.duration = d
        m.retryTimer.control = "stop"
        m.retryTimer.control = "start"
    else
        m.failed = true
        m.stallTimer.control = "stop"
        m.retryTimer.control = "stop"
        m.video.control = "stop"
        lem = LCase(detail)
        why = ""
        if Instr(1, lem, "codec") > 0 or Instr(1, lem, "unsupported") > 0 or Instr(1, lem, "decod") > 0 or Instr(1, lem, "format") > 0
            why = " It uses a video or audio format Roku can't decode (for example MPEG-2 or HEVC video)."
        else if Instr(1, lem, "403") > 0 or Instr(1, lem, "401") > 0
            why = " The provider refused the connection (check that no other device is using the same login)."
        end if
        msg = "This channel can't play on Roku." + why + " Press OK to try again, " + Chr(9650) + Chr(9660) + " for another channel, or Back to exit."
        if it <> invalid and it.kind = "catchup" then msg = "This catch-up programme isn't available from your provider. Press Back to exit."
        if it <> invalid and it.kind <> "live" and it.kind <> "catchup" then msg = "This video can't play on Roku." + why + " Press OK to try again or Back to exit."
        if detail <> "" then msg = msg + Chr(10) + "Details: " + detail
        m.pStatus.text = msg
        m.pStatus.visible = true
        showOsd(false)
        ' the stopped Video node can swallow OK; give focus to the scene so OK / ▲▼ / Back always arrive
        m.top.setFocus(true)
    end if
end sub

sub onStallTick()
    if m.screen <> "player" then
        m.stallTimer.control = "stop"
        return
    end if
    st = m.video.state
    if st = "buffering" and not m.paused
        m.bufSecs = m.bufSecs + 1
        m.samePosSecs = 0
        if m.bufSecs >= 15 and isLive()
            m.bufSecs = 0
            retryPlayback()
        end if
    else if st = "playing"
        m.bufSecs = 0
        ' A stream counts as working after 20 s of real playback; then the retry budget resets.
        m.playingSecs = m.playingSecs + 1
        if m.playingSecs >= 20 and m.retries > 0
            ' remember the format that works: it goes first next time (reconnect, LIVE, OK)
            v = [m.curVariant]
            for each x in m.variants
                if not (x.url = m.curVariant.url and x.fmt = m.curVariant.fmt) then v.push(x)
            end for
            m.variants = v
            m.retries = 0
            m.pStatus.visible = false
        end if
        ' 2.0.2 watchdog: "playing" but the picture is stuck (position not moving) on live TV.
        p = Int(m.video.position)
        if isLive() and not m.paused
            ' only once the position has been seen moving, so a stream that never reports a
            ' position is not mistaken for a frozen one
            if p = m.lastPos
                m.samePosSecs = m.samePosSecs + 1
            else
                if m.lastPos >= 0 and p > m.lastPos then m.posMoved = true
                m.samePosSecs = 0
            end if
            m.lastPos = p
            if m.posMoved = true and m.samePosSecs >= 15
                m.samePosSecs = 0
                m.playingSecs = 0
                retryPlayback()
            end if
        end if
    else
        m.bufSecs = 0
    end if
    if m.osd.visible and isLive() then updateTimeline()
end sub

' Live DVR window: Roku reports the seekable live window of a sliding HLS playlist in duration.
sub onVideoPosition()
    if not isLive() then return
    d = m.video.duration
    if d <> invalid and d > 60
        m.dvr = true
        m.window = d
    end if
end sub

function behindLive() as integer
    if not m.dvr then return 0
    b = Int(m.video.duration - m.video.position)
    if b < 0 then b = 0
    return b
end function

sub seekBy(delta as integer)
    if not isLive()
        p = m.video.position + delta
        if p < 0 then p = 0
        m.video.seek = p
        return
    end if
    if not m.dvr
        if delta < 0
            showToast("Rewind isn't available on this channel (no time-shift window from the provider)")
        else
            showToast("You're watching live")
        end if
        return
    end if
    target = m.video.position + delta
    edge = m.video.duration - 3
    if target < 0 then target = 0
    if target >= edge
        goLive()
        return
    end if
    m.video.seek = target
    showOsd(false)
end sub

sub togglePause()
    st = m.video.state
    if st = "paused"
        resumePlayback()
    else if st = "playing" or st = "buffering"
        m.video.control = "pause"
        m.paused = true
        m.pausedAt = nowSecs()
        m.pauseBadge.visible = true
        setPauseLabel("Play")
        showOsd(true)
    end if
end sub

sub resumePlayback()
    m.pauseBadge.visible = false
    setPauseLabel("Pause")
    if isLive()
        gap = nowSecs() - m.pausedAt
        ' No time-shift window (or paused longer than it): the paused point is gone, rejoin live.
        if (not m.dvr and gap > 20) or (m.dvr and gap > m.window - 10)
            showToast("Back to live")
            m.retries = 0
            startPlayback(0)
            showOsd(false)
            return
        end if
    end if
    m.paused = false
    m.video.control = "resume"
end sub

sub goLive()
    if not isLive() then return
    if m.paused or behindLive() > 8
        m.retries = 0
        startPlayback(0)
        showToast("● LIVE")
    end if
    showOsd(false)
end sub

sub setPauseLabel(t as string)
    c = m.ctrl.content.getChild(1)
    if c <> invalid then c.title = t
end sub

' ---------------- overlay ----------------
sub showOsd(focusControls as boolean)
    it = currentItem()
    if it = invalid then return
    if not isLive() and it.kind <> "catchup"
        return
    end if
    num = it.num
    if num = invalid or num = "" then num = (m.playIdx + 1).ToStr()
    m.chBadge.text = "CH " + num
    m.osdTitle.text = it.title
    m.osdLogo.uri = it.HDPosterUrl
    w = m.osdTitle.boundingRect().width
    if w > 1300 then w = 1300
    sx = 80 + w + 18
    if it.fav = true then m.osdStar.uri = "pkg:/images/star.png" else m.osdStar.uri = "pkg:/images/star_o.png"
    m.osdStar.translation = [sx, 806]
    m.osdStar.visible = it.kind = "live"
    m.osdCu.visible = it.archive > 0
    m.osdCu.translation = [sx + 52, 804]
    refreshOsdEpg()
    if isLive()
        if isX() and not epgFresh(it.sid)
            m.epgList = m.playList
            m.epgCol = m.playIdx
            onEpgTimer()
        end if
        hint = "▲▼ Channels   ◀ ▶ -10s / +30s   OK Controls   * Favorite"
        m.ctrl.visible = true
    else
        hint = "OK Pause   ◀ ▶ Seek   Back Exit"
        m.ctrl.visible = false
    end if
    m.osdHint.text = hint
    updateTimeline()
    m.osd.visible = true
    if focusControls and m.ctrl.visible
        m.ctrl.jumpToItem = 1
        m.ctrl.setFocus(true)
    end if
    m.osdTimer.control = "stop"
    m.osdTimer.control = "start"
end sub

sub refreshOsdEpg()
    it = currentItem()
    if it = invalid then return
    m.osdSub.text = ""
    m.osdNow.text = ""
    m.osdNext.text = ""
    m.osdProg.width = 0
    m.osdProgBg.width = 1760
    m.curProg = invalid
    if it.kind <> "live" then return
    e = epgNowNext(it.sid)
    if e = invalid then
        m.osdSub.text = "Live"
        return
    end if
    if e.now <> invalid
        m.curProg = e.now
        m.osdSub.text = e.now.t
        m.osdNow.text = hhmm(e.now.s) + " – " + hhmm(e.now.e)
    end if
    if e.next <> invalid then m.osdNext.text = "Next " + hhmm(e.next.s) + ": " + e.next.t
    updateTimeline()
end sub

sub updateTimeline()
    full = 1760
    f = 1.0
    if m.curProg <> invalid and m.curProg.e > m.curProg.s
        f = (nowSecs() - m.curProg.s) / (m.curProg.e - m.curProg.s)
        if f < 0 then f = 0
        if f > 1 then f = 1
    end if
    b = behindLive()
    m.osdProg.width = Int(full * f)
    head = full * f
    if m.dvr and m.window > 0
        head = full * (1 - b / m.window)
    end if
    if head < 0 then head = 0
    m.osdHead.translation = [80 + Int(head) - 4, 898]
    live = m.ctrl.content.getChild(3)
    if b > 8 or m.paused
        m.osdShift.text = "-" + clockText(b) + " behind live"
        live.sel = false
    else
        m.osdShift.text = ""
        live.sel = true
    end if
end sub

sub hideOsd()
    if m.ctrl.hasFocus() or m.chList.hasFocus() or m.paused then
        m.osdTimer.control = "start"
        return
    end if
    m.osd.visible = false
end sub

sub onCtrlSelected()
    c = m.ctrl.content.getChild(m.ctrl.itemSelected)
    a = c.act
    if a = "back"
        seekBy(-10)
    else if a = "fwd"
        seekBy(30)
    else if a = "pause"
        togglePause()
    else if a = "live"
        goLive()
    else if a = "list"
        openChannelList()
    end if
    m.osdTimer.control = "stop"
    m.osdTimer.control = "start"
end sub

sub openChannelList()
    m.chList.content = m.playList
    m.chList.jumpToItem = m.playIdx
    m.chPanel.visible = true
    m.chList.setFocus(true)
end sub

sub onChListSelected()
    i = m.chList.itemSelected
    m.chPanel.visible = false
    if i <> m.playIdx then zapTo(i)
    m.video.setFocus(true)
end sub

sub zap(d as integer)
    n = m.playList.getChildCount()
    if n = 0 then return
    i = m.playIdx
    ' skip placeholder tiles
    for t = 1 to n
        i = (i + d + n) mod n
        c = m.playList.getChild(i)
        if c <> invalid and c.kind = "live" then exit for
    end for
    zapTo(i)
end sub

sub zapTo(i as integer)
    m.playIdx = i
    m.retries = 0
    it = currentItem()
    if it <> invalid then addRecent(it)
    startPlayback(0)
    showOsd(false)
end sub

sub stopPlayback(savePos = true as boolean)
    it = currentItem()
    if savePos and it <> invalid and (it.kind = "movie" or it.kind = "episode")
        posS = Int(m.video.position)
        dur = m.video.duration
        if posS > 30 and (dur = invalid or dur = 0 or posS < dur - 120) then setRecentPos(it, posS) else setRecentPos(it, 0)
    end if
    m.retryTimer.control = "stop"
    m.stallTimer.control = "stop"
    m.osdTimer.control = "stop"
    m.video.control = "stop"
    setPlayerChrome(false)
    m.osd.visible = false
    m.chPanel.visible = false
    m.pauseBadge.visible = false
    m.pStatus.visible = false
    m.screen = m.prevScreen
    if m.screen = "" then m.screen = "main"
    if m.prevFocus <> invalid then m.prevFocus.setFocus(true)
    if m.screen = "main" and m.tab = "home" and m.rows.content <> invalid
        rf = m.rows.rowItemFocused
        if rf <> invalid and rf.count() = 2 then markFavs(m.rows.content.getChild(rf[0]))
    end if
end sub

function playerKey(key as string) as boolean
    if m.dlg <> invalid then return false
    if key = "back"
        if m.chPanel.visible
            m.chPanel.visible = false
            m.video.setFocus(true)
        else if m.ctrl.hasFocus()
            m.osd.visible = false
            m.video.setFocus(true)
        else
            stopPlayback(true)
        end if
        return true
    end if
    if key = "options"
        it = currentItem()
        if it <> invalid and it.kind <> "catchup"
            toggleFav(it)
            if m.osd.visible then showOsd(m.ctrl.hasFocus())
        end if
        return true
    end if
    if m.chPanel.visible then return false
    it = currentItem()
    if it = invalid then return false
    if it.kind <> "live"
        ' movies / episodes / catch-up use Roku's built-in trick-play UI (enableUI)
        if key = "OK" and m.failed = true
            m.retries = 0
            startPlayback(0)
            return true
        end if
        return false
    end if
    if key = "up"
        zap(-1)
        return true
    else if key = "down"
        zap(1)
        return true
    else if key = "play"
        togglePause()
        return true
    else if key = "rewind" or key = "replay"
        seekBy(-10)
        return true
    else if key = "fastforward"
        seekBy(30)
        return true
    end if
    if m.ctrl.hasFocus()
        m.osdTimer.control = "stop"
        m.osdTimer.control = "start"
        return false
    end if
    if key = "left"
        seekBy(-10)
        return true
    else if key = "right"
        seekBy(30)
        return true
    else if key = "OK" or key = "info"
        if m.failed = true
            m.retries = 0
            startPlayback(0)
        end if
        showOsd(true)
        return true
    end if
    return false
end function
