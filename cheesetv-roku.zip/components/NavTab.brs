' CheeseTV: navigation pill. MIT License, (c) 2026 CheeseTV.
sub init()
    m.pill = m.top.findNode("pill")
    m.base = m.top.findNode("base")
    m.chip = false
    m.under = m.top.findNode("under")
    m.lbl = m.top.findNode("lbl")
    m.w = 180
    m.h = 60
    m.sel = false
    m.content = invalid
end sub

sub onContent()
    if m.content <> invalid then m.content.unobserveFieldScoped("sel")
    m.content = m.top.itemContent
    if m.content = invalid then return
    m.content.observeFieldScoped("sel", "onSel")
    m.lbl.text = m.content.title
    ch = m.content.chip
    m.chip = (ch = true)
    m.base.visible = m.chip
    onSel()
    layout()
end sub

sub onSel()
    s = m.content.sel
    m.sel = (s = true)
    onFocus()
end sub

sub layout()
    if m.top.width > 0 then m.w = m.top.width
    if m.top.height > 0 then m.h = m.top.height
    m.base.width = m.w
    m.base.height = m.h
    m.pill.width = m.w
    m.pill.height = m.h
    m.lbl.width = m.w
    m.lbl.height = m.h
    m.under.width = m.w - 60
    m.under.translation = [30, m.h - 6]
end sub

sub onFocus()
    has = m.top.gridHasFocus or m.top.rowListHasFocus
    p = m.top.focusPercent
    if not has then p = 0
    m.pill.opacity = p
    m.under.visible = m.sel and p < 0.5 and not m.chip
    if m.chip
        if m.sel then m.base.blendColor = "0x4A3D12FF" else m.base.blendColor = "0x111B33FF"
    end if
    if p > 0.5
        m.lbl.color = "0x1A1300FF"
    else if m.sel
        m.lbl.color = "0xF5C242FF"
    else
        m.lbl.color = "0xF4F6FBFF"
    end if
end sub
