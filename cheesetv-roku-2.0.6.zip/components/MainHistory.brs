' CheeseTV 2.0.4: Continue watching per series (last episode + position), movie resume,
' watched marks (>= 90%) and cross-device sync of progress + favorites.
' Registry keys (per playlist): ser_<id> { seriesId: {e,s,n,p,d,u,w,t,g,x} }, mov_<id> { movieId: {p,d,u,w,t,g,x} },
' wat_<id> [ids]. u = UTC seconds of the change. No URLs or passwords are stored here.

function progBudget() as integer
    b = Int(favBudget() / 2.5)
    if b < 600 then b = 600
    return b
end function

sub loadHistory()
    m.serProg = regRead("ser_" + m.acc.id, {})
    if type(m.serProg) <> "roAssociativeArray" then m.serProg = {}
    m.movProg = regRead("mov_" + m.acc.id, {})
    if type(m.movProg) <> "roAssociativeArray" then m.movProg = {}
    w = regRead("wat_" + m.acc.id, [])
    m.watchedList = []
    m.watched = {}
    if type(w) = "roArray"
        for each id in w
            m.watchedList.push(toStr(id))
            m.watched[toStr(id)] = true
        end for
    end if
    m.lastPush = {}
    m.lastLocal = {}
    m.syncPulledAt = invalid
    m.syncKey = ""
    if isX() and toStr(m.acc.user) <> "" then m.syncKey = SyncKey(toStr(m.acc.server), toStr(m.acc.user), toStr(m.acc.pass))
end sub

' Keeps the newest entries of a map whose JSON fits maxBytes (drops posters first, then the oldest).
function fitMap(mp as object, maxBytes as integer) as object
    if Len(FormatJson(mp)) <= maxBytes then return mp
    keys = sortedKeys(mp)
    for i = keys.count() - 1 to 0 step -1
        if mp[keys[i]].g <> invalid then mp[keys[i]].Delete("g")
        if Len(FormatJson(mp)) <= maxBytes then return mp
    end for
    i = keys.count() - 1
    while i >= 0 and Len(FormatJson(mp)) > maxBytes
        mp.Delete(keys[i])
        i = i - 1
    end while
    return mp
end function

' keys newest first (by u)
function sortedKeys(mp as object) as object
    arr = []
    for each k in mp
        arr.push({ k: k, u: toInt(mp[k].u) })
    end for
    arr.SortBy("u", "r")
    out = []
    for each a in arr
        out.push(a.k)
    end for
    return out
end function

sub saveHistory()
    b = progBudget()
    m.serProg = fitMap(m.serProg, Int(b / 2))
    m.movProg = fitMap(m.movProg, Int(b * 3 / 10))
    while m.watchedList.count() > 0 and Len(FormatJson(m.watchedList)) > Int(b / 5)
        m.watched.Delete(m.watchedList.Shift())
    end while
    regWriteAsync("ser_" + m.acc.id, m.serProg)
    regWriteAsync("mov_" + m.acc.id, m.movProg)
    regWriteAsync("wat_" + m.acc.id, m.watchedList)
end sub

sub markWatched(id as string)
    if id = "" or m.watched.DoesExist(id) then return
    m.watched[id] = true
    m.watchedList.push(id)
end sub

function isWatched(id as string) as boolean
    return m.watched <> invalid and m.watched.DoesExist(id)
end function

function utcNow() as integer
    return CreateObject("roDateTime").AsSeconds()
end function

function isoOf(secs as integer) as string
    d = CreateObject("roDateTime")
    d.FromSeconds(secs)
    return d.ToISOString()
end function

function parseIso(s as string) as integer
    if Len(s) < 19 then return 0
    d = CreateObject("roDateTime")
    d.FromISO8601String(Left(s, 19) + "Z")
    return d.AsSeconds()
end function

function fieldOf(it as object, f as string) as dynamic
    if it.hasField(f) then return it[f]
    return invalid
end function

' Called while playing (throttled), on pause/stop and when an item finishes.
sub trackProgress(it as dynamic, posS as integer, dur as integer, final as boolean)
    if it = invalid or m.serProg = invalid then return
    k = it.kind
    if k <> "movie" and k <> "episode" then return
    if toStr(it.sid) = "" then return
    now = utcNow()
    key = k + ":" + it.sid
    if not final and m.lastLocal[key] <> invalid and now - m.lastLocal[key] < 15 then return
    m.lastLocal[key] = now
    w = dur > 0 and posS >= dur * 0.9
    if w then markWatched(it.sid)
    rec = invalid
    if k = "movie"
        rec = { p: posS, d: dur, u: now, w: w, t: Left(toStr(it.title), 40) }
        if Len(toStr(it.HDPosterUrl)) <= 160 then rec.g = it.HDPosterUrl
        if toStr(it.ext) <> "" then rec.x = it.ext
        m.movProg[it.sid] = rec
    else
        ser = toStr(fieldOf(it, "ser"))
        if ser <> ""
            st = ""
            if m.seriesItem <> invalid and m.seriesItem.sid = ser then st = toStr(m.sTitle.text)
            old = m.serProg[ser]
            if st = "" and old <> invalid then st = toStr(old.t)
            rec = { e: it.sid, s: toInt(fieldOf(it, "sea")), n: toInt(fieldOf(it, "epn")), p: posS, d: dur, u: now, w: w, t: Left(st, 40) }
            g = ""
            if m.seriesItem <> invalid and m.seriesItem.sid = ser then g = toStr(m.seriesItem.HDPosterUrl)
            if g = "" and old <> invalid then g = toStr(old.g)
            if g <> "" and Len(g) <= 160 then rec.g = g
            if toStr(it.ext) <> "" then rec.x = it.ext
            m.serProg[ser] = rec
        end if
    end if
    saveHistory()
    if rec = invalid then return
    if final or m.lastPush[key] = invalid or now - m.lastPush[key] >= 30
        m.lastPush[key] = now
        pushProgress(k, it.sid, toStr(fieldOf(it, "ser")), rec, toStr(it.title))
    end if
end sub

' Saved position for a movie / episode from the series or movie progress (0 = none / watched).
function progPos(it as object) as integer
    if m.serProg = invalid or toStr(it.sid) = "" then return 0
    if it.kind = "movie"
        r = m.movProg[it.sid]
        if r <> invalid and r.w <> true then return toInt(r.p)
    else if it.kind = "episode"
        ser = toStr(fieldOf(it, "ser"))
        if ser <> ""
            r = m.serProg[ser]
            if r <> invalid and r.e = it.sid and r.w <> true then return toInt(r.p)
        end if
    end if
    return 0
end function

' ---------------- Continue watching lists (Movies / Series chip) ----------------
function continueList(mode as string) as object
    list = CreateObject("roSGNode", "ContentNode")
    if m.serProg = invalid then return list
    if mode = "movies"
        for each id in sortedKeys(m.movProg)
            r = m.movProg[id]
            if r.w <> true and toInt(r.p) > 0
                it = recToNode({ k: "movie", i: id, t: r.t, g: r.g, x: r.x, p: r.p }, m.acc, fmtPref(), list)
                it.fav = m.favSet.DoesExist("movie:" + id)
            end if
        end for
    else if mode = "series"
        for each id in sortedKeys(m.serProg)
            r = m.serProg[id]
            t = toStr(r.t)
            if t = "" then t = "Series"
            it = recToNode({ k: "series", i: id, t: t + "  ·  S" + toStr(r.s) + "E" + toStr(r.n), g: r.g }, m.acc, fmtPref(), list)
            it.addFields({ cont: true })
            it.fav = m.favSet.DoesExist("series:" + id)
        end for
    end if
    return list
end function

sub removeContinue(it as object)
    if it.kind = "movie" then m.movProg.Delete(it.sid)
    if it.kind = "series" then m.serProg.Delete(it.sid)
    saveHistory()
end sub

' ---------------- Series page: watched checks + "Continue S1E3" ----------------
sub decorateSeries(seriesId as string, seasons as object)
    if m.serProg = invalid then return
    target = invalid
    tS = 0 : tE = 0
    r = m.serProg[seriesId]
    found = false
    for si = 0 to seasons.getChildCount() - 1
        sn = seasons.getChild(si)
        for ei = 0 to sn.getChildCount() - 1
            e = sn.getChild(ei)
            if isWatched(e.sid) then e.title = "✓ " + e.title
            if found and target = invalid
                target = e : tS = si : tE = ei
            end if
            if r <> invalid and e.sid = toStr(r.e)
                if r.w = true
                    found = true
                else
                    target = e : tS = si : tE = ei
                    found = true
                end if
            end if
        end for
    end for
    if target = invalid then return
    c = CreateObject("roSGNode", "ContentNode")
    c.title = "▶ Continue S" + toStr(fieldOf(target, "sea")) + "E" + toStr(fieldOf(target, "epn"))
    c.addFields({ cont: true, sIdx: tS + 1, eIdx: tE })
    seasons.insertChild(c, 0)
end sub

sub onSeasonSelected()
    if m.seasonsRoot = invalid then return
    c = m.seasonsRoot.getChild(m.seasons.itemSelected)
    if c = invalid then return
    if c.hasField("cont") and c.cont = true
        playContinue()
    else if c.getChildCount() > 0
        m.episodes.setFocus(true)
    end if
end sub

sub playContinue()
    c = m.seasonsRoot.getChild(0)
    if c = invalid or not c.hasField("cont") then return
    sn = m.seasonsRoot.getChild(c.sIdx)
    if sn = invalid then return
    e = sn.getChild(c.eIdx)
    if e = invalid then return
    m.episodes.content = sn
    m.episodes.jumpToItem = c.eIdx
    playItem(e, sn, c.eIdx)
end sub

' ---------------- sync ----------------
function SyncKey(server as string, user as string, pass as string) as string
    s = LCase(server.Trim())
    i = Instr(1, s, "://")
    if i > 0 then s = Mid(s, i + 3)
    i = Instr(1, s, "/")
    if i > 0 then s = Left(s, i - 1)
    i = Instr(1, s, ":")
    if i > 0 then s = Left(s, i - 1)
    ba = CreateObject("roByteArray")
    ba.FromAsciiString(s + "|" + user + "|" + pass)
    d = CreateObject("roEVPDigest")
    d.Setup("sha256")
    return LCase(d.Process(ba))
end function

sub syncSend(fn as string, body as object)
    if m.syncKey = invalid or m.syncKey = "" then return
    if m.syncTask = invalid
        m.syncTask = CreateObject("roSGNode", "SyncTask")
        m.syncTask.observeField("result", "onSyncResult")
        m.syncTask.control = "RUN"
    end if
    body.p_key = m.syncKey
    m.syncReq = toInt(m.syncReq) + 1
    m.syncTask.job = { fn: fn, body: body, id: m.syncReq }
end sub

sub pushProgress(k as string, id as string, ser as string, r as object, title as string)
    b = { p_item_type: k, p_item_id: id, p_title: Left(title, 300), p_position_s: toInt(r.p), p_duration_s: toInt(r.d), p_watched: r.w = true, p_updated_at: isoOf(toInt(r.u)) }
    if k = "episode"
        b.p_series_id = ser : b.p_season = toInt(r.s) : b.p_episode = toInt(r.n)
        if toStr(r.t) <> "" then b.p_title = Left(toStr(r.t) + " S" + toStr(r.s) + "E" + toStr(r.n), 300)
    end if
    syncSend("sync_put_progress", b)
end sub

sub pushFavorite(it as object, added as boolean)
    if toStr(it.sid) = "" then return
    b = { p_item_type: it.kind, p_item_id: it.sid, p_title: Left(toStr(it.title), 300), p_fav: added }
    if Len(toStr(it.HDPosterUrl)) <= 1000 then b.p_poster = toStr(it.HDPosterUrl)
    syncSend("sync_set_favorite", b)
end sub

' sync_get on login and when Movies / Series opens (at most once a minute).
sub syncPull()
    if m.syncKey = invalid or m.syncKey = "" then return
    if m.syncPulledAt <> invalid and m.syncPulledAt.TotalSeconds() < 60 then return
    m.syncPulledAt = CreateObject("roTimespan")
    syncSend("sync_get", {})
end sub

sub onSyncResult()
    res = m.syncTask.result
    if type(res) <> "roAssociativeArray" or res.ok <> true or type(res.data) <> "roAssociativeArray" then return
    d = res.data
    seenSer = {}
    seenMov = {}
    changed = false
    if type(d.progress) = "roArray"
        for each p in d.progress
            u = parseIso(toStr(p.updated_at))
            id = toStr(p.item_id)
            if p.watched = true then markWatched(id)
            if p.item_type = "movie" and id <> ""
                seenMov[id] = true
                l = m.movProg[id]
                if l = invalid or toInt(l.u) < u
                    nr = { p: toInt(p.position_s), d: toInt(p.duration_s), u: u, w: p.watched = true, t: Left(toStr(p.title), 40) }
                    if l <> invalid and l.g <> invalid then nr.g = l.g
                    if l <> invalid and l.x <> invalid then nr.x = l.x
                    m.movProg[id] = nr
                    changed = true
                else if toInt(l.u) > u
                    pushProgress("movie", id, "", l, toStr(l.t))
                end if
            else if p.item_type = "episode" and toStr(p.series_id) <> ""
                ser = toStr(p.series_id)
                if not seenSer.DoesExist(ser)
                    seenSer[ser] = true
                    l = m.serProg[ser]
                    if l = invalid or toInt(l.u) < u
                        t = toStr(p.title)
                        sfx = " S" + toStr(p.season) + "E" + toStr(p.episode)
                        if Right(t, Len(sfx)) = sfx then t = Left(t, Len(t) - Len(sfx))
                        nr = { e: id, s: toInt(p.season), n: toInt(p.episode), p: toInt(p.position_s), d: toInt(p.duration_s), u: u, w: p.watched = true, t: Left(t, 40) }
                        if l <> invalid and l.g <> invalid then nr.g = l.g
                        m.serProg[ser] = nr
                        changed = true
                    else if toInt(l.u) > u
                        pushProgress("episode", toStr(l.e), ser, l, toStr(l.t))
                    end if
                end if
            end if
        end for
    end if
    ' local entries the server doesn't have yet (or has older)
    for each id in m.movProg
        if not seenMov.DoesExist(id) then pushProgress("movie", id, "", m.movProg[id], toStr(m.movProg[id].t))
    end for
    for each ser in m.serProg
        if not seenSer.DoesExist(ser) then pushProgress("episode", toStr(m.serProg[ser].e), ser, m.serProg[ser], toStr(m.serProg[ser].t))
    end for
    ' favorites: union
    if type(d.favorites) = "roArray"
        added = 0
        for each f in d.favorites
            key = toStr(f.item_type) + ":" + toStr(f.item_id)
            if toStr(f.item_id) <> "" and not m.favSet.DoesExist(key) and m.favs.count() < 40
                rec = { k: toStr(f.item_type), i: toStr(f.item_id), t: Left(toStr(f.title), 48) }
                if Len(toStr(f.poster)) <= 160 and toStr(f.poster) <> "" then rec.g = toStr(f.poster)
                m.favs.push(rec)
                m.favSet[key] = true
                added = added + 1
            end if
        end for
        if added > 0
            saveFavs()
            if m.tab = "vfav" and m.screen = "main" and not m.grid.hasFocus() then showVodFavs()
        end if
    end if
    if changed then saveHistory()
end sub

' 2.0.4: "♥ Favorites" tab next to Movies / Series: every favorited series and movie (synced).
sub showVodFavs()
    m.gridGroup.visible = true
    m.gridMode = "movies"
    chips = CreateObject("roSGNode", "ContentNode")
    row = chips.createChild("ContentNode")
    f = row.createChild("ContentNode")
    f.title = "♥ Favorites"
    f.addFields({ chip: true, sel: true, catId: "*vfav" })
    m.chips.content = chips
    m.chipSel = 0
    setGridLayout("movies")
    list = CreateObject("roSGNode", "ContentNode")
    for each r in m.favs
        if r.k = "series" or r.k = "movie"
            it = recToNode(r, m.acc, fmtPref(), list)
            it.fav = true
        end if
    end for
    setGridContent(list, "No favorites yet", "Tap ♥ on any show to save it here")
end sub
